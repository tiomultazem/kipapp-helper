# tablePopup
import tkinter as tk
import tableDef as td
from theme import ToolTip
from tkinter import ttk, messagebox, filedialog
# --- Tambah import di atas file ---
import os
from openpyxl import Workbook
import preprocess as pp
from preprocess import cleaning, filter_month, bulan_map
import app
import threading

def run_cleaning(gui, parent):
    if not gui.cleaned_data or not gui.cleaned_headers:
        messagebox.showwarning("Belum Ada Data", "Data belum diimpor.", parent=parent)
        return

    colmap = {h.lower(): i for i, h in enumerate(gui.cleaned_headers)}
    success, headers, cleaned = cleaning(
        data=gui.cleaned_data,
        colmap=colmap,
        update_log=gui.update_log_gui
    )
    if success:
        gui.cleaned_headers = headers
        gui.cleaned_data = cleaned
        gui.update_log_gui("✅ Cleaning selesai.")
        app.set_runtime_status("idle", "success")
    else:
        gui.update_log_gui("❌ Cleaning gagal.")
        app.set_runtime_status("idle", "error")

def run_filter_bulan(gui, parent):
    if not gui.cleaned_data or not gui.cleaned_headers:
        messagebox.showwarning("Belum Ada Data", "Data belum diimpor.", parent=parent)
        return

    bulan = gui.inputMonth_var.get().lower()
    bulan_num = bulan_map.get(bulan)
    if not bulan_num:
        gui.update_log_gui(f"❌ Bulan tidak valid: {bulan}")
        return

    # Normalisasi header -> index
    colmap = { (str(h).strip().lower() if h is not None else ""): i
               for i, h in enumerate(gui.cleaned_headers) }

    # Guard: pastikan kolom 'tanggal' ada
    if "tanggal" not in colmap:
        gui.update_log_gui("❌ Tidak ada kolom tanggal ditemukan.")
        app.set_runtime_status("idle", "error")
        return

    try:
        filtered = filter_month(
            ws=None,
            colmap=colmap,
            bulan_filter=bulan_num,
            set_runtime_status=None,
            rows=gui.cleaned_data
        )
    except KeyError as e:
        # Catch tambahan bila ada akses kolom yang tidak ditemukan
        if str(e).strip("'").lower() == "tanggal":
            gui.update_log_gui("❌ Tidak ada kolom tanggal ditemukan.")
            app.set_runtime_status("idle", "error")
            return
        else:
            gui.update_log_gui(f"❌ Kolom tidak ditemukan: {e}")
            app.set_runtime_status("idle", "error")
            return

    gui.cleaned_data = filtered
    gui.update_log_gui(f"✅ Filter bulan {bulan} selesai. Tersisa {len(filtered)} baris.")

def unduh_tabel(gui, parent):
    if not getattr(gui, "cleaned_headers", None):
        messagebox.showwarning("Belum Ada Data", "Silakan pilih dan proses file Excel terlebih dahulu.", parent=parent)
        return

    target_dir = filedialog.askdirectory(
        parent=parent,                  # <<< penting agar dialog modal di popup
        title="Pilih folder untuk menyimpan skp.xlsx",
        mustexist=True
    )
    if not target_dir:
        return

    out_path = os.path.join(target_dir, "skp.xlsx")
    try:
        wb = Workbook()
        wsx = wb.active
        wsx.append(list(gui.cleaned_headers))
        for r in (gui.cleaned_data or []):
            wsx.append(list(r))
        wb.save(out_path)

        log_msg = f"✅ Telah mengunduh skp.xlsx ke {target_dir}"
        if hasattr(gui, "update_log_gui") and callable(gui.update_log_gui):
            gui.update_log_gui(log_msg)
        elif hasattr(gui, "update_log") and callable(gui.update_log):
            gui.update_log(log_msg)
        else:
            messagebox.showinfo("Unduh Tabel", log_msg, parent=parent)
    except Exception as e:
        messagebox.showerror("Gagal Mengunduh", f"Terjadi kesalahan saat menyimpan file:\n{e}", parent=parent)

def show_excel_as_table(gui):
    if not gui.cleaned_headers:
        messagebox.showwarning("Belum Ada Data", "Silakan pilih dan proses file Excel terlebih dahulu.")
        return
    if not gui.cleaned_data:
        messagebox.showwarning("Data Kosong", "Import berhasil tetapi tidak ada baris data.")

    try:
        popup = tk.Toplevel(gui.master)
        if gui.dark_mode_enabled:
            popup.configure(bg="#171717")
        popup.title("Isi File Excel SKP")
        popup.geometry("900x500")

        frame = ttk.Frame(popup)
        frame.pack(fill="both", expand=True)

        columns_with_check = ["__checked__", "__no__"] + gui.cleaned_headers
        tree = ttk.Treeview(frame, columns=columns_with_check, show="headings", selectmode="extended")

        checkbox_all_state = {"checked": False}  # simpan state centang semua

        # tree.heading("__checked__", text="✓", command=toggle_all_checkboxes)
        tree.heading("__checked__", text="✓", command=lambda: td.toggle_all_checkboxes(tree, checkbox_all_state))
        tree.column("__checked__", width=30, anchor="center")

        tree.heading("__no__", text="No")
        tree.column("__no__", width=50, anchor="center")

        sort_directions = {}

        tree.bind("<Button-1>", lambda e: td.on_row_click(e, tree))

        style = ttk.Style()
        style.map("Treeview", background=[("selected", "#007fff")])

        tree.bind("<Motion>", lambda e: td.on_hover(e, tree, gui))

        for col in gui.cleaned_headers:
            tree.heading(col, text=col, command=lambda c=col: td.sort_by_column(tree, c, sort_directions))
            tree.column(col, anchor="w", width=150)

        for idx, row in enumerate(gui.cleaned_data, start=1):
            tree.insert("", "end", values=["☐", idx] + list(row))

        v_scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=v_scroll.set)
        v_scroll.pack(side="right", fill="y")

        h_scroll = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(xscrollcommand=h_scroll.set)
        h_scroll.pack(side="bottom", fill="x")

        tree.pack(fill="both", expand=True)

        # === CONTAINER FRAME UNTUK 2 KOLOM ===
        dual_frame = ttk.Frame(popup)
        dual_frame.pack(fill="x", padx=10, pady=5)

        dual_frame.columnconfigure(0, weight=1, uniform="columns")
        dual_frame.columnconfigure(1, weight=1, uniform="columns")
        dual_frame.columnconfigure(2, weight=1, uniform="columns")


        # State toggle edit
        edit_mode_state = {"active": False}

        # === FRAME CLEANING DATA (KOLOM KANAN) ===
        cleaning_frame = ttk.LabelFrame(dual_frame, text="Preprocessing", padding="8")
        cleaning_frame.grid(row=0, column=0, padx=(0, 5), sticky="nsew")

        for i in range(3):
            cleaning_frame.columnconfigure(i, weight=1, uniform="a")
        # Ganti tombol di cleaning_frame
        btn_toggle_edit = ttk.Button(
            cleaning_frame,
            text="✏️",
            style="Blue.TButton",
            command=lambda: td.toggle_edit_mode(tree, btn_toggle_edit, edit_mode_state, gui)
            )
        btn_toggle_edit.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        btn_toggle_edit.tooltip_text = "aktifkan edit"

        btn_tambah_baris = ttk.Button(
            cleaning_frame, 
            text="➕", 
            style="Blue.TButton", 
            command=lambda: td.tambah_baris_kosong(tree, gui, checkbox_all_state, sort_directions, edit_mode_state)
            )
        btn_tambah_baris.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        btn_tambah_baris.tooltip_text = "tambah baris"

        btn_cleaning = ttk.Button(
            cleaning_frame,text="♻️", style="Blue.TButton",
            command=lambda: (run_cleaning(gui, popup),
                td.update_treeview_data(tree, gui, checkbox_all_state, lambda c: td.sort_by_column(tree, c, sort_directions))))
        btn_cleaning.grid(row=0, column=2, padx=5, pady=5, sticky="ew")
        btn_cleaning.tooltip_text = "cleaning"

        btn_filter = ttk.Button(
            cleaning_frame, text="✂️", style="Blue.TButton",
            command=lambda: (run_filter_bulan(gui, popup),
                td.update_treeview_data(tree, gui, checkbox_all_state, lambda c: td.sort_by_column(tree, c, sort_directions))))
        btn_filter.grid(row=1, column=0, padx=5, pady=5, sticky="ew")
        btn_filter.tooltip_text = "filter bulan"

        btn_hapus = ttk.Button(cleaning_frame, text="❌", style="Red.TButton", command=lambda: td.hapus_baris_tercentang(tree, gui))
        btn_hapus.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        btn_hapus.tooltip_text = "hapus baris tercentang"

        btn_unduh = ttk.Button(cleaning_frame, text="▼", style="Blue.TButton", command=lambda: unduh_tabel(gui, popup))
        btn_unduh.grid(row=1, column=2, padx=5, pady=5, sticky="ew")
        btn_unduh.tooltip_text = "unduh tabel"

        # Tooltip hover
        ToolTip(btn_toggle_edit, "aktifkan edit")
        ToolTip(btn_tambah_baris, "tambah baris")
        ToolTip(btn_cleaning, "cleaning")
        ToolTip(btn_filter, "filter bulan")
        ToolTip(btn_hapus, "hapus baris tercentang")
        ToolTip(btn_unduh, "unduh tabel")

        # === FRAME PENGATURAN API (KOLOM KIRI) ===
        bukti_frame = ttk.LabelFrame(dual_frame, text="Manajemen Bukti Dukung", padding="8")
        bukti_frame.grid(row=0, column=1, padx=(5, 0), sticky="nsew")

        for i in range(3):
            bukti_frame.columnconfigure(i, weight=1, uniform="a")

        btn_rename_file_in_folder = ttk.Button(bukti_frame, text="🖊️", style="Blue.TButton", command=gui.rename_file_in_folder)
        btn_rename_file_in_folder.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        btn_rename_file_in_folder.tooltip_text = "ganti nama bukti dukung di folder dengan tanggal + kegiatan"

        btn_rname_file_in_table = ttk.Button(bukti_frame, text="✒️", style="Blue.TButton", command=gui.rename_file_in_table)
        btn_rname_file_in_table.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        btn_rname_file_in_table.tooltip_text = "ganti nama bukti dukung di tabel dari folder"

        btn_get_nama_file = ttk.Button(
            bukti_frame,
            text="🫳",
            style="Blue.TButton",
            command=lambda: (gui.get_nama_file(), 
                td.update_treeview_data(tree, gui, checkbox_all_state, lambda c: td.sort_by_column(tree, c, sort_directions)))
        )
        btn_get_nama_file.grid(row=0, column=2, padx=5, pady=5, sticky="ew")
        btn_get_nama_file.tooltip_text = "cari dan ganti nama file di tabel dari folder"
        
        ttk.Label(bukti_frame, text="Path File Bukti:").grid(row=1, column=0, padx=5, pady=5, sticky="e")
        rename_entry = ttk.Entry(bukti_frame, textvariable=gui.rename_dir_var, style="Kipapp.TEntry")
        rename_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        btn_pilih_folder = ttk.Button(
            bukti_frame,
            text="Pilih Folder",
            command=gui.select_rename_folder,
            style="Blue.TButton"
        )
        btn_pilih_folder.grid(row=1, column=2, padx=5, pady=5, sticky="ew")

        ToolTip(btn_rename_file_in_folder, "ganti nama bukti dukung di folder dengan tanggal + kegiatan")
        ToolTip(btn_rname_file_in_table, "ganti nama bukti dukung di tabel")
        ToolTip(btn_get_nama_file, "cari dan ganti nama file di tabel dari folder")

        # === FRAME PENGATURAN API (KOLOM KIRI) ===
        api_frame = ttk.LabelFrame(dual_frame, text="Pengaturan API", padding="8")
        api_frame.grid(row=0, column=2, padx=(5, 0), sticky="nsew")

        for i in range(3):
            api_frame.columnconfigure(i, weight=1, uniform="a")

        ttk.Label(api_frame, text="API Key:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
        api_key_entry = ttk.Entry(api_frame, textvariable=gui.api_key_var, style="Kipapp.TEntry")
        api_key_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(api_frame, text="API Secret:").grid(row=1, column=0, padx=5, pady=5, sticky="e")
        api_secret_entry = ttk.Entry(api_frame, textvariable=gui.api_secret_var, style="Kipapp.TEntry")
        api_secret_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        btn_import_api = ttk.Button(
            api_frame,
            text="Import API",
            command=gui.import_api_keys,
            style="Blue.TButton"
        )
        btn_import_api.grid(row=0, column=2, rowspan=2, padx=5, pady=5, sticky="nsew")

        ttk.Label(api_frame, text="Path Drive BPS:").grid(row=2, column=0, padx=5, pady=5, sticky="e")
        api_path_entry = ttk.Entry(api_frame, textvariable=gui.api_path_var, style="Kipapp.TEntry")
        api_path_entry.grid(row=2, column=1, padx=5, pady=5, sticky="ew")

        btn_ubah_link = ttk.Button(
            api_frame,
            text="Ubah Link",
            command=lambda: threading.Thread(target=gui.run_extract_links, daemon=True).start(),
            style="Blue.TButton"
        )
        btn_ubah_link.grid(row=2, column=2, padx=5, pady=5, sticky="ew")
 
        
    except Exception as e:
        messagebox.showerror("Gagal Buka Tabel", f"Terjadi kesalahan saat menampilkan tabel:\n{e}")
    gui.tree_ref = tree