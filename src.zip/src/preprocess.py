import datetime
bulan_map = {
    'januari': '01', 'februari': '02', 'maret': '03', 'april': '04',
    'mei': '05', 'juni': '06', 'juli': '07', 'agustus': '08',
    'september': '09', 'oktober': '10', 'november': '11', 'desember': '12'
}
bulan_indo_map = {
            "january": "januari", "february": "februari", "march": "maret", "april": "april",
            "may": "mei", "june": "juni", "july": "juli", "august": "agustus",
            "september": "september", "october": "oktober", "november": "november", "december": "desember"
        }
bulan_tri_map = {
    "01": "jan","02": "feb","03": "mar","04": "apr",
    "05": "mei","06": "jun","07": "jul","08": "agu",
    "09": "sep","10": "okt","11": "nov","12": "des"
}

bulan_tri_to_full_map = {
    "jan": "Januari", "feb": "Februari", "mar": "Maret", "apr": "April",
    "mei": "Mei", "jun": "Juni", "jul": "Juli", "agu": "Agustus",
    "sep": "September", "okt": "Oktober", "nov": "November", "des": "Desember"
}

def cleaning(data, colmap, update_log=None):
    result_rows = []
    cleaned_headers = ["tanggal", "RK SKP atau keywordnya", "kegiatan", "capaian", "Upload bukti dukung"]

    # for row in data:
    for idx, row in enumerate(data, start=1):
        try:
            tgl_raw = row[colmap['tanggal']]
            # Default: isi tgl_obj pakai nilai mentahnya
            tgl_obj = tgl_raw

            # Jika bisa diparse, baru overwrite
            if isinstance(tgl_raw, (datetime.date, datetime.datetime)):
                tgl_obj = tgl_raw.date() if isinstance(tgl_raw, datetime.datetime) else tgl_raw
            else:
                s = (str(tgl_raw).strip() if tgl_raw is not None else "")
                for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y"):
                    try:
                        tgl_obj = datetime.datetime.strptime(s, fmt).date()
                        break
                    except Exception:
                        pass

            if not tgl_obj:
                continue

            rk_skp = str(row[colmap.get('rk skp atau keywordnya', '')]).strip()
            kegiatan = str(row[colmap.get('pre-kegiatan', '')]).strip() + " " + str(row[colmap.get('kegiatan', '')]).strip()
            capaian = str(row[colmap.get('kegiatan', '')]).strip() + " sebanyak " + str(int(float(row[colmap.get('jumlah capaian', '')]))) + " " + str(row[colmap.get('jenis capaian', '')]).strip()
            bukti = str(row[colmap.get('upload bukti dukung', '')]).strip()

            result_rows.append([tgl_obj, rk_skp, kegiatan, capaian, bukti])
        except Exception as e:
            if update_log:
                # update_log(f"❌ Error di baris ke-{idx}: {e}")
                update_log(f"❌ Error di baris ke-{idx}: Isian tidak sesuai format pra-cleaning atau sudah clean. Silakan periksa format anda.")
            break

    if not result_rows:
        # if update_log:
        #     update_log("❌ Gagal: tidak ada data untuk dibersihkan.")
        return False, [], []

    return True, cleaned_headers, result_rows

def filter_month(ws=None, colmap=None, bulan_filter="", set_runtime_status=None, rows=None):
    if set_runtime_status:
        set_runtime_status("busy", "none")

    if rows is not None:
        iter_rows = rows
    elif ws is not None:
        iter_rows = ws.iter_rows(min_row=2, values_only=True)
    else:
        return []

    result_rows = []
    for r_idx, row in enumerate(iter_rows, start=2):
        tgl_obj = row[colmap['tanggal']]
        tgl = tgl_obj.strftime("%Y-%m-%d") if isinstance(tgl_obj, datetime.datetime) else str(tgl_obj)
        if not tgl:
            continue
        # cek range tanggal dan waktu
        if str(tgl).lower().startswith("range"):
            sebelum_kurung = str(tgl).split("(")[0].strip()
            parts = sebelum_kurung.split()

            if len(parts) < 3:
                update_log(f"⚠️ Format kurang spasi di '{tgl}'. Gunakan spasi sebelum nama bulan, misalnya 'range 5-12 sep'")
                # Tetap coba pisahkan bulan dari angka
                last_part = parts[-1]
                bulan_str = ''.join(filter(str.isalpha, last_part))
            else:
                bulan_str = parts[-1]

            if bulan_str != bulan_tri_map[bulan_filter]:
                continue
        else:
            if str(tgl)[5:7] != bulan_filter:
                continue

        # if str(tgl).lower().startswith("range"):
        #     if str(tgl).split()[-1] != bulan_tri_map[bulan_filter]:
        #         continue
        # else:
        #     if str(tgl)[5:7] != bulan_filter:
        #         continue
        
        result_rows.append(row)

    if set_runtime_status:
        set_runtime_status("idle", "success")
    return result_rows


