# theme.py
import tkinter as tk
from tkinter import ttk
from config import set
class ToolTip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tipwindow = None
        widget.bind("<Enter>", self.show)
        widget.bind("<Leave>", self.hide)

    def show(self, event=None):
        if self.tipwindow or not self.text:
            return
        x = y = 0
        x += self.widget.winfo_rootx() + 30
        y += self.widget.winfo_rooty() + 20
        self.tipwindow = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        label = tk.Label(
            tw, text=self.text, justify='left',
            background="#ffffe0", relief='solid', borderwidth=1,
            font=("tahoma", "8", "normal")
        )
        label.pack(ipadx=6, ipady=3)

    def hide(self, event=None):
        if self.tipwindow:
            self.tipwindow.destroy()
            self.tipwindow = None

def apply_dark(gui):
    style = ttk.Style()

    # DARK MODE
    gui.original_bg = "#171717"
    gui.original_fg = "#f0f0f0"
    gui.original_log_bg = "#303030"
    gui.original_log_fg = "#f0f0f0"
    gui.master.configure(bg="#171717")
    style.configure("TFrame", background="#212121")
    style.configure("TLabel", background="#212121", foreground="white")
    style.configure("TCheckbutton", background="#212121", foreground="white")
    style.configure("TLabelframe", background="#212121", foreground="white")
    style.configure("TLabelframe.Label", background="#212121", foreground="white")

    style.configure("Blue.TButton", background="#2a4d6f", foreground="white")
    style.configure("Green.TButton", background="#2f5e2f", foreground="white")
    style.configure("Red.TButton", background="#702f37", foreground="white")
    style.configure("Yellow.TButton", background="#6a5600", foreground="white")
    style.configure("Plain.TButton", background="#444444", foreground="white")

    style.configure("Kipapp.TEntry", foreground="white", fieldbackground="#444444")
    style.configure("Kipapp.TSpinbox", foreground="white", fieldbackground="#303030", background="#303030")

    style.configure("Treeview", background="#303030", foreground="white",
                    fieldbackground="#303030", bordercolor="#444444")
    style.map("Treeview",
              background=[("selected", "#4444aa")],
              foreground=[("selected", "white")])

    style.configure("KiPApp.TCombobox", fieldbackground="#171717", background="#171717", foreground="white")
    style.map("KiPApp.TCombobox",
              fieldbackground=[("readonly", "#171717")],
              background=[("readonly", "#171717")],
              foreground=[("readonly", "white")],
              selectbackground=[("readonly", "#171717")],
              selectforeground=[("readonly", "white")])

    gui.footer_frame.config(bg="#171717")
    gui.label_kiri.config(bg="#171717", fg="white")
    gui.label_kanan.config(bg="#171717", fg="white")
    gui.love.config(bg="#171717", fg="white")
    gui.label_copyright.config(bg="#171717", fg="white")
    gui.log_text.config(bg="#303030", fg="white", insertbackground="white")
    gui.logo_label.config(bg="#212121")

def apply_light(gui):
    style = ttk.Style()

    # LIGHT MODE
    style.theme_use("clam")
    gui.original_bg = "white"
    gui.original_fg = "#171717"
    gui.original_log_bg = "#f0f0f0"
    gui.original_log_fg = "#171717"
    gui.master.configure(bg=gui.original_bg)

    style.configure("TFrame", background="#f0f0f0")
    style.configure("TLabel", background="#f0f0f0", foreground="#171717")
    style.configure("TCheckbutton", background="#f0f0f0", foreground="#171717")
    style.configure("TLabelframe", background="#f0f0f0", foreground="#171717")
    style.configure("TLabelframe.Label", background="#f0f0f0", foreground="#171717")

    style.configure("Blue.TButton", background="#aedff7", padding=(4, 2), foreground="#171717")
    style.configure("Green.TButton", background="#c9f7cf", padding=(4, 2), foreground="#171717")
    style.configure("Red.TButton", background="#f9c5c5", padding=(4, 2), foreground="#171717")
    style.configure("Yellow.TButton", background="#FFF3B0", padding=(4, 2), foreground="#171717")
    style.configure("Plain.TButton", padding=(4, 2), background="#f0f0f0", foreground="#171717")

    style.configure("Treeview", background="white", foreground="black", fieldbackground="white")
    style.map("Treeview",
              background=[("selected", "#007fff")],
              foreground=[("selected", "white")])

    style.configure("Kipapp.TEntry", foreground="#171717", fieldbackground="white")
    style.configure("Kipapp.TSpinbox", foreground="#171717", fieldbackground="white", background="white")

    style.map("KiPApp.TCombobox",
              fieldbackground=[("readonly", "white")],
              background=[("readonly", "white")],
              foreground=[("readonly", "#171717")],
              selectbackground=[("readonly", "white")],
              selectforeground=[("readonly", "#171717")])

    gui.footer_frame.config(bg=gui.original_bg)
    gui.label_kiri.config(bg=gui.original_bg, fg="#808080")
    gui.label_kanan.config(bg=gui.original_bg, fg="#808080")
    gui.love.config(bg=gui.original_bg, fg="#808080")
    gui.label_copyright.config(bg=gui.original_bg, fg="#808080")
    gui.log_text.config(bg=gui.original_bg, fg="#808080", insertbackground="#808080")
    gui.logo_label.config(bg="#f0f0f0")

def toggle_theme(gui):
    """
    Hanya membalik nilai gui.dark_mode_enabled dan menyimpan ke config.
    Tidak menerapkan styling di sini.
    """
    gui.dark_mode_enabled = not gui.dark_mode_enabled
    set("dark_mode_enabled", gui.dark_mode_enabled)
