# updatePopup
import os
import shutil
import zipfile
import requests
import subprocess
import tkinter as tk
from tkinter import messagebox, ttk
import json


CONFIG_PATH = "config.json"
REPO_CONFIG_URL = "https://raw.githubusercontent.com/tiomultazem/kipapp-helper/main/config.json"
REPO_CHANGELOG_URL = "https://raw.githubusercontent.com/tiomultazem/kipapp-helper/main/changelog.json"


def run_updater():
    """
    Mengunduh versi terbaru dari GitHub dan menimpa file lokal yang diperbarui.
    File yang diupdate: build/, changelog.json, config.json, README.md.
    Setelah selesai → tampilkan countdown & restart app.
    """
    REPO_ZIP_URL = "https://github.com/tiomultazem/kipapp-helper/archive/refs/heads/main.zip"
    TMP_ZIP = "tmp_update.zip"
    TMP_FOLDER = "update_tmp"
    ROOT_FOLDER_NAME = "kipapp-helper-main"  # folder di dalam ZIP GitHub

    try:
        # 1️⃣ Unduh file zip dari repo
        messagebox.showinfo("Update", "Mengunduh versi terbaru dari GitHub...")
        r = requests.get(REPO_ZIP_URL, timeout=10)
        with open(TMP_ZIP, "wb") as f:
            f.write(r.content)

        # 2️⃣ Ekstrak zip ke folder sementara
        with zipfile.ZipFile(TMP_ZIP, "r") as zip_ref:
            zip_ref.extractall(TMP_FOLDER)

        # 3️⃣ Ganti file dan folder yang diperbarui
        src_root = os.path.join(TMP_FOLDER, ROOT_FOLDER_NAME)

        # Folder build
        if os.path.exists("build"):
            shutil.rmtree("build")
        shutil.copytree(os.path.join(src_root, "build"), "build")

        # File changelog.json, config.json, README.md
        for file_name in ["changelog.json", "config.json", "README.md"]:
            src_file = os.path.join(src_root, file_name)
            if os.path.exists(src_file):
                shutil.copy2(src_file, file_name)

        # 4️⃣ Hapus file zip & folder sementara
        os.remove(TMP_ZIP)
        shutil.rmtree(TMP_FOLDER, ignore_errors=True)

        # 5️⃣ Popup countdown restart
        def tampilkan_countdown():
            popup = tk.Toplevel()
            popup.title("Berhasil Diperbarui")
            popup.geometry("350x120")
            popup.resizable(False, False)
            popup.attributes("-topmost", True)

            label = tk.Label(
                popup,
                text="✅ Berhasil meng-update.\nAplikasi akan dimulai ulang dalam 5 detik.",
                font=("Segoe UI", 10),
                justify="center",
            )
            label.pack(expand=True, padx=10, pady=20)

            def update_label(detik):
                if detik > 0:
                    label.config(
                        text=f"✅ Berhasil meng-update.\nAplikasi akan dimulai ulang dalam {detik} detik."
                    )
                    popup.after(1000, update_label, detik - 1)
                else:
                    popup.destroy()
                    subprocess.Popen(["python", "main.py"])
                    os._exit(0)

            popup.after(1000, update_label, 4)

        tampilkan_countdown()

    except Exception as e:
        messagebox.showerror("Gagal Update", f"Terjadi kesalahan saat update:\n{e}")


def ambil_changelog_dict():
    try:
        r = requests.get(REPO_CHANGELOG_URL, timeout=5)
        if r.status_code != 200:
            return None
        data = r.json()
        if not isinstance(data, dict):
            return None
        return data
    except Exception:
        return None


def pisah_changelog_terbaru_dan_riwayat(changelog_dict, ver_terbaru):
    if not changelog_dict:
        return None, None

    versi_list = sorted(changelog_dict.keys(), reverse=True)

    # changelog versi terbaru
    log_terbaru = changelog_dict.get(ver_terbaru) or []
    if log_terbaru:
        bagian_terbaru = "\n".join(f"• {x}" for x in log_terbaru)
    else:
        bagian_terbaru = None

    # riwayat semua versi (desc)
    riwayat_lines = []
    for v in versi_list:
        logs = changelog_dict.get(v) or []
        if not logs:
            continue
        riwayat_lines.append(f"Versi {v}:")
        for item in logs:
            riwayat_lines.append(f"  • {item}")
        riwayat_lines.append("")  # pemisah kosong

    riwayat_text = "\n".join(riwayat_lines).strip()
    if not riwayat_text:
        riwayat_text = None

    return bagian_terbaru, riwayat_text


def tanya_update_dengan_riwayat(root, local_ver, remote_ver, changelog_terbaru, riwayat_text):
    win = tk.Toplevel(root)
    win.title("Pembaruan Tersedia")
    win.geometry("480x360")
    win.resizable(False, False)
    win.attributes("-topmost", True)

    frm = ttk.Frame(win, padding=10)
    frm.pack(fill="both", expand=True)

    header = f"Ada versi terbaru ({remote_ver}).\nVersi anda saat ini ({local_ver})."
    ttk.Label(frm, text=header, justify="left").pack(anchor="w")

    if changelog_terbaru:
        ttk.Label(frm, text="\nApa yang baru di versi ini:", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        ttk.Label(frm, text=changelog_terbaru, justify="left").pack(anchor="w")

    if riwayat_text:
        ttk.Label(frm, text="\nRiwayat Update (versi terbaru ke lama, scroll ke bawah untuk detail):", font=("Segoe UI", 9, "bold")).pack(anchor="w")

        box_frame = ttk.Frame(frm)
        box_frame.pack(fill="both", expand=True, pady=(2, 0))

        text = tk.Text(box_frame, height=8, wrap="word")
        scroll = ttk.Scrollbar(box_frame, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)

        text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        text.insert("1.0", riwayat_text)
        text.config(state="disabled")

    btn_frame = ttk.Frame(frm)
    btn_frame.pack(fill="x", pady=(10, 0))

    result = {"jawab": False}

    def on_yes():
        result["jawab"] = True
        win.destroy()

    def on_no():
        win.destroy()

    ttk.Button(btn_frame, text="Yes", width=8, command=on_yes).pack(side="right", padx=(5, 0))
    ttk.Button(btn_frame, text="No", width=8, command=on_no).pack(side="right")

    win.transient(root)
    win.grab_set()
    root.wait_window(win)
    return result["jawab"]


def cek_update_otomatis(silent=False, root=None):
    """Jika silent=True, hanya munculkan popup bila ada update atau versi lokal > repo."""
    if not os.path.exists(CONFIG_PATH):
        if not silent:
            messagebox.showerror("Error", "config.json lokal tidak ditemukan.")
        return

    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            local_conf = json.load(f)
            local_ver = str(local_conf.get("version", "0"))
    except Exception as e:
        if not silent:
            messagebox.showerror("Error", f"Gagal membaca config lokal: {e}")
        return

    try:
        r = requests.get(REPO_CONFIG_URL, timeout=5)
        if r.status_code != 200:
            if not silent:
                messagebox.showerror("Gagal Cek Update", f"Tidak bisa mengakses GitHub (status {r.status_code})")
            return
        remote_conf = r.json()
        remote_ver = str(remote_conf.get("version", "0"))
    except Exception as e:
        if not silent:
            messagebox.showerror("Gagal Cek Update", f"Gagal memeriksa versi GitHub:\n{e}")
        return

    # logika perbandingan
    if local_ver == remote_ver:
        if not silent:
            messagebox.showinfo("Pembaruan", f"Versi anda saat ini ({local_ver}) sudah yang terbaru.")
        return

    if local_ver > remote_ver:
        if not silent:
            messagebox.showinfo(
                "Peringatan", f"Versi lokal ({local_ver}) lebih tinggi dari repo ({remote_ver})."
            )
        return

    # local_ver < remote_ver → ada update
    changelog_dict = ambil_changelog_dict()
    changelog_terbaru, riwayat_text = pisah_changelog_terbaru_dan_riwayat(changelog_dict, remote_ver)

    if root is None:
        # fallback ke messagebox biasa kalau root tidak disuplai
        pesan = f"Ada versi terbaru ({remote_ver}).\nVersi anda saat ini ({local_ver})."
        if changelog_terbaru:
            pesan += f"\n\nApa yang baru di versi ini:\n{changelog_terbaru}"
        pesan += "\n\nUpdate ke versi terbaru?"
        jawab = messagebox.askyesno("Pembaruan Tersedia", pesan)
    else:
        jawab = tanya_update_dengan_riwayat(root, local_ver, remote_ver, changelog_terbaru, riwayat_text)

    if jawab:
        run_updater()


def run_updatePopup(root):
    """Mode startup — hanya tampilkan bila versi berbeda (tidak terbaru)."""
    root.after(2000, lambda: cek_update_otomatis(silent=True, root=root))
