# printLogo
from PIL import Image
import os

def print_logo_terminal(image_path, width):
    os.system("cls")
    # ascii monoton
    # try:
    #     img = Image.open(image_path).convert('L')
    #     width, height = img.size
    #     ratio = height / width / 1.65  # adjust for terminal aspect ratio
    #     new_height = int(new_width * ratio)
    #     img = img.resize((new_width, new_height))
    #     pixels = img.getdata()
    #     chars = [" ", ".", ":", "-", "=", "+", "*", "#", "%", "@"]
    #     new_pixels = [chars[pixel//25] for pixel in pixels]
    #     ascii_image = [new_pixels[index:index + new_width] for index in range(0, len(new_pixels), new_width)]
    #     for line in ascii_image:
    #         print("".join(line))
    # except Exception as e:
    #     print(f"[!] Gagal cetak logo: {e}")
    # ascii colored
    ascii_chars = "@%#*+=-:. "  # dari gelap ke terang
    try:
        img = Image.open(image_path).convert("RGB")
        w, h = img.size
        aspect_ratio = 0.5  # huruf terminal ≈ 2x tinggi gambar
        new_height = int((h / w) * width * aspect_ratio)
        img = img.resize((width, new_height))

        for y in range(new_height):
            for x in range(width):
                r, g, b = img.getpixel((x, y))
                brightness = int(0.299 * r + 0.587 * g + 0.114 * b)
                char = ascii_chars[brightness * len(ascii_chars) // 256]
                print(f"\x1b[38;2;{r};{g};{b}m{char}\x1b[0m", end="")
            print()
    except Exception as e:
        print(f"[!] Gagal render ASCII logo warna: {e}")
    # # pixellated image
    # try:
    #     img = Image.open(image_path).convert('RGB')
    #     w, h = img.size
    #     aspect_ratio = 0.5  # tinggi huruf terminal ≈ 2x lebarnya
    #     new_height = int((h / w) * width * aspect_ratio)
    #     img = img.resize((width, new_height))
    #     pixels = img.load()

    #     for y in range(new_height):
    #         for x in range(width):
    #             r, g, b = pixels[x, y]
    #             print(f"\x1b[48;2;{r};{g};{b}m ", end="")  # █ atau ' ' untuk blok warna
    #         print("\x1b[0m")  # Reset warna setiap baris

    # except Exception as e:
    #     print(f"[!] Gagal menampilkan logo berwarna: {e}")
