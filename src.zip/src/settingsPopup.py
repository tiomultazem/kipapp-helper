# settings.py

import tkinter as tk
from tkinter import ttk, filedialog
from updatePopup import cek_update_otomatis
import app, aboutPopup
import config

def open_settings_popup(gui):
    popup = tk.Toplevel(gui.master)
    popup.title("Opsi")
    popup.geometry("500x400")
    popup.transient(gui.master)
    popup.grab_set()

    if gui.dark_mode_enabled:
        popup.configure(bg="#171717")

    label = ttk.Label(popup, text="Opsi Aplikasi", font=("Arial", 11, "bold"))
    label.pack(pady=(10, 5))

    def browse_chrome_path():
        path = filedialog.askopenfilename(
            title="Pilih chrome.exe",
            filetypes=[("Executable", "chrome.exe")],
            initialdir="C:/Program Files/Google/Chrome/Application"
        )
        if path:
            gui.chrome_path_var.set(path)
            app.user_defined_chrome_path = path
            config.set("chrome_path", path)   # simpan ke config.json
            gui.update_log_gui(f"📌 Lokasi Chrome diset: {path}")


    def simpan_chrome_path():
        app.user_defined_chrome_path = gui.chrome_path_var.get().strip()
        config.set("chrome_path", app.user_defined_chrome_path)   # ⬅ tambah ini
        gui.update_log_gui("📌 Lokasi Chrome disimpan.")

    def simpan_time_sleep():
        app.set_dropdown_delay(gui.delay_dropdown_var.get())
        app.set_rk_delay(gui.delay_rk_var.get())
        app.set_klikrk_delay(gui.delay_klikrk_var.get())
        app.set_isirk_delay(gui.delay_isirk_var.get())
        app.set_kliktgl_delay(gui.delay_kliktgl_var.get())
        app.set_isitgl_delay(gui.delay_isitgl_var.get())
        app.set_submit_delay(gui.delay_submit_var.get())
        app.set_jeda_delay(gui.delay_jeda_var.get())

        gui.update_log_gui(f"Delay Dropdown diatur menjadi {gui.delay_dropdown_var.get()} detik.")
        gui.update_log_gui(f"Delay RK diatur menjadi {gui.delay_rk_var.get()} detik.")
        gui.update_log_gui(f"Delay Klik RK diatur menjadi {gui.delay_klikrk_var.get()} detik.")
        gui.update_log_gui(f"Delay Isi RK diatur menjadi {gui.delay_isirk_var.get()} detik.")
        gui.update_log_gui(f"Delay Klik Tgl diatur menjadi {gui.delay_kliktgl_var.get()} detik.")
        gui.update_log_gui(f"Delay Isi Tgl diatur menjadi {gui.delay_isitgl_var.get()} detik.")
        gui.update_log_gui(f"Delay Submit diatur menjadi {gui.delay_submit_var.get()} detik.")
        gui.update_log_gui(f"Delay Jeda Tiap 5 diatur menjadi {gui.delay_jeda_var.get()} detik.")

    def default_time_sleep():
        app.reset_all_delays_to_default()
        gui.delay_dropdown_var.set(app.dropdown_delay)
        gui.delay_rk_var.set(app.rk_delay)
        gui.delay_klikrk_var.set(app.klikrk_delay)
        gui.delay_isirk_var.set(app.isirk_delay)
        gui.delay_kliktgl_var.set(app.kliktgl_delay)
        gui.delay_isitgl_var.set(app.isitgl_delay)
        gui.delay_submit_var.set(app.submit_delay)
        gui.delay_jeda_var.set(app.jeda_delay)

        gui.update_log_gui("⏱️ Semua delay dikembalikan ke nilai default.")

    def show_about_and_update():
        aboutPopup.show_about_popup(gui.master, gui)
        config.set("hide_about",False)
        gui.update_log_gui("ℹ️ About akan ditampilkan di sesi berikutnya.")

    # GUI
    chrome_row = ttk.Frame(popup)
    chrome_row.pack(padx=20, pady=5, fill="x")

    chrome_label = ttk.Label(chrome_row, text="Lokasi Chrome:")
    chrome_label.pack(side="left")

    # gui.chrome_path_var = tk.StringVar(value=app.user_defined_chrome_path)
    gui.chrome_path_var = tk.StringVar(value=config.get("chrome_path"))
    chrome_entry = ttk.Entry(chrome_row, textvariable=gui.chrome_path_var, width=40, style="Kipapp.TEntry")
    chrome_entry.pack(side="left", padx=(5, 0), expand=True, fill="x")

    browse_btn = ttk.Button(chrome_row, text="📂", width=3, command=browse_chrome_path, style="Plain.TButton")
    browse_btn.pack(side="left", padx=(5, 0))

    btn_simpan = ttk.Button(chrome_row, text="Simpan", command=simpan_chrome_path, style="Plain.TButton")
    btn_simpan.pack(side="left", padx=(5, 0))

    delay_frame = ttk.LabelFrame(popup, text="Delay")
    delay_frame.pack(padx=20, pady=5, fill="x")

    # List delay: (label, variabel)
    delay_options = [
        ("Dropdown", gui.delay_dropdown_var),
        ("RK", gui.delay_rk_var),
        ("Klik RK", gui.delay_klikrk_var),
        ("Isi RK", gui.delay_isirk_var),
        ("Klik Tgl", gui.delay_kliktgl_var),
        ("Isi Tgl", gui.delay_isitgl_var),
        ("Submit", gui.delay_submit_var),
        ("Jeda Tiap 5", gui.delay_jeda_var),
    ]

    left_frame = ttk.Frame(delay_frame)
    mid_frame = ttk.Frame(delay_frame)
    right_frame = ttk.Frame(delay_frame)

    left_frame.grid(row=0, column=0, padx=(5, 5), pady=5, sticky="n")
    mid_frame.grid(row=0, column=1, padx=(5, 5), pady=5, sticky="n")
    right_frame.grid(row=0, column=2, padx=(10, 5), pady=5, sticky="n")

    for i, (label_text, var) in enumerate(delay_options):
        if i % 2 == 0:
            parent = left_frame
        else:
            parent = mid_frame
        row = ttk.Frame(parent)
        row.pack(anchor="w", pady=2)

        label = ttk.Label(row, text=f"{label_text}:", width=12)
        label.pack(side="left")

        spinner = ttk.Spinbox(
            row, 
            from_=0, 
            to=10, 
            increment=0.1, 
            format="%.1f", 
            width=5, 
            textvariable=var,
            style="Kipapp.TSpinbox"
        )
        spinner.pack(side="left", padx=(5, 0))

    # Tombol simpan
    btn_simpan_delay = ttk.Button(right_frame, text="Atur", command=simpan_time_sleep, style="Plain.TButton")

    btn_reset = ttk.Button(right_frame, text="Default", command=default_time_sleep, style="Plain.TButton")
    btn_simpan_delay.grid(row=0, column=0, padx=10, pady=5, sticky="ew")
    btn_reset.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
    right_frame.grid_rowconfigure((0,1), weight=1)
    # frame khusus untuk tombol di bagian bawah
    bottom_btn_frame = ttk.Frame(popup)
    bottom_btn_frame.pack(pady=(5, 10), anchor="e", padx=15)  # ada jarak dari kanan (px=15)

    btn_cek_update = ttk.Button(bottom_btn_frame, text="Cek Update", command=lambda: cek_update_otomatis(silent=False), style="Blue.TButton")
    btn_cek_update.pack(side="left", padx=(0, 8))

    btn_show_about = ttk.Button(bottom_btn_frame, text="Show About", command=show_about_and_update, style="Blue.TButton")
    btn_show_about.pack(side="left", padx=(0, 8))  # ada jarak 8px ke kanan

    btn_tutup = ttk.Button(bottom_btn_frame, text="Tutup", command=popup.destroy, style="Red.TButton")
    btn_tutup.pack(side="left")