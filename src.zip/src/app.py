from openpyxl import load_workbook
from preprocess import cleaning, filter_month, bulan_map, bulan_tri_to_full_map
import tempfile
import shutil
import time
import os
import sys
import requests
import urllib.parse
from xml.etree import ElementTree as ET
from shutil import which
import config
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException, NoSuchElementException, ElementClickInterceptedException, WebDriverException
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import datetime
from io import BytesIO

# Global variables
log_extract_result = []  # ← buat buffer log global
driver = None
temp_user_data_dir = None
log_callback = None
excel_file_path = ""
session = None
ws = None
# TEMPLATE LAMPU
runtime_state = "idle"       # idle, busy
runtime_result = "none"      # none, success, error
status_callback = None
# set_runtime_status("idle/busy", "none/success/error")

# Nilai aktif
dropdown_delay  = 3
rk_delay        = 1.5
klikrk_delay    = 0.5
isirk_delay     = 0.3
kliktgl_delay   = 0.6
isitgl_delay    = 0.6
submit_delay    = 1
jeda_delay      = 3

# Nilai default (JANGAN DIPAKAI untuk runtime)
DEFAULT_DROPDOWN_DELAY  = 3
DEFAULT_RK_DELAY        = 1.5
DEFAULT_KLIKRK_DELAY    = 0.5
DEFAULT_ISIRK_DELAY     = 0.3
DEFAULT_KLIKTGL_DELAY   = 0.6
DEFAULT_ISITGL_DELAY    = 0.6
DEFAULT_SUBMIT_DELAY    = 1
DEFAULT_JEDA_DELAY      = 3

tahun_ini = datetime.datetime.now().year

# UNTUK LAMPU
def get_runtime_status():
    return runtime_state, runtime_result
def set_status_callback(cb):
    global status_callback
    status_callback = cb
def set_runtime_status(state, result):
    global runtime_state, runtime_result
    runtime_state = state
    runtime_result = result
    if status_callback:
        status_callback(state, result)

def set_log_callback(callback_func):
    global log_callback
    log_callback = callback_func

def update_log(message):
    if log_callback:
        log_callback(message)
    else:
        print(message)

def navigasi(input_month_name):
    set_runtime_status("busy", "none")
    global driver
    if not driver:
        update_log("ERROR: Browser belum diinisialisasi atau login belum berhasil.")
        set_runtime_status("idle", "error")
        return False
    try:
        # nav baru
        target_url = "https://kipapp.bps.go.id/#/pelaksanaan-aksi"
        current_url = driver.current_url
        if current_url.strip().lower() == target_url.lower():
            update_log("ℹ️ Sudah di halaman Pelaksanaan Kinerja.")
            return True
        update_log("\nMemulai navigasi dan pemilihan SKP...")
        driver.get(target_url)
        update_log("Berhasil masuk halaman 'Pelaksanaan Kinerja - Pelaksanaan'.")
        time.sleep(dropdown_delay)
        pilih_skp_dropdown = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[contains(@class, 'ant-col') and contains(., 'Periode SKP')]/following-sibling::div//div[@role='combobox']"))
        )
        pilih_skp_dropdown.click()
        time.sleep(0.5)
        search_input_field = driver.switch_to.active_element
        search_input_field.send_keys(f"bulan {input_month_name}")

        time.sleep(0.1)
        search_input_field.send_keys(Keys.ARROW_DOWN)
        search_input_field.send_keys(Keys.ENTER)
        update_log("\nOtomatisasi pemilihan periode SKP selesai.")
        set_runtime_status("idle", "success")
        return True
    except ElementClickInterceptedException:
        update_log("Navigasi gagal. Tutup dulu semua popup.")
        set_runtime_status("idle", "error")
        return False

    ##DEV##
    except Exception as e:
        # update_log(f"ERROR di navigasi: {e}")
        return False
    ##DEV##

# rentang tanggal
# rentang tanggal
# rentang tanggal
def ensure_checkbox_rentang(driver, kliktgl_delay, update_log, should_be_checked):
    try:
        checkbox_label = driver.find_element(By.XPATH,
            "//label[.//span[contains(text(),'Gunakan periode tanggal')]]"
        )
        checkbox_input = checkbox_label.find_element(By.TAG_NAME, "input")
        is_checked = checkbox_input.is_selected()

        if is_checked != should_be_checked:
            checkbox_label.click()
            time.sleep(kliktgl_delay)

    except Exception as e:
        update_log(f"⚠️ Checkbox 'Gunakan periode tanggal' tidak ditemukan atau gagal diklik: {e}")

def handler_tglrange(driver, tanggal_str, kliktgl_delay, update_log, set_runtime_status):
    try:
        sebelum_kurung = tanggal_str.split("(")[0].strip()
        parts = sebelum_kurung.split()

        if len(parts) < 3 or parts[0].lower() != "range":
            raise ValueError

        rng = parts[1]
        bulan_str = parts[2]
        bulan_full = bulan_tri_to_full_map.get(bulan_str.lower())
        # Deteksi kesalahan umum: tidak ada spasi sebelum bulan
        if not bulan_str.isalpha():
            update_log(f"⚠️ Kemungkinan format salah pada '{tanggal_str}': gunakan spasi sebelum nama bulan (mis. 'range 5-12 sep')")
            # Tapi tetap lanjutkan

        start_day, end_day = rng.split("-")
        start_day = ''.join(filter(str.isdigit, start_day.strip()))
        end_day = ''.join(filter(str.isdigit, end_day.strip()))

    except Exception:
        update_log(f"❌ Format range salah: {tanggal_str}. Gunakan 'range x-y <bulan>'.")
        set_runtime_status("idle", "error")
        return False

    try:
        awal_input = driver.find_element(By.XPATH, "//input[contains(@placeholder,'Pilih tanggal awal')]")
        awal_input.click()
        time.sleep(kliktgl_delay)
    except:
        ensure_checkbox_rentang(driver, kliktgl_delay, update_log, should_be_checked=True)
        awal_input = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//input[contains(@placeholder,'Pilih tanggal awal')]"))
        )
        awal_input.click()
        time.sleep(kliktgl_delay)

    # driver.find_element(By.XPATH, f"//div[contains(@class,'ant-calendar-date') and text()='{start_day}']").click()
    # driver.find_element(By.XPATH, f"//div[contains(@class,'ant-calendar-date') and text()='{end_day}']").click()
    driver.find_element(
        By.XPATH, f"//td[@title='{int(start_day)} {bulan_full} {tahun_ini}']//div[contains(@class,'ant-calendar-date')]"
    ).click()

    driver.find_element(
        By.XPATH, f"//td[@title='{int(end_day)} {bulan_full} {tahun_ini}']//div[contains(@class,'ant-calendar-date')]"
    ).click()


    return True
# rentang tanggal
# rentang tanggal
# rentang tanggal

### helper global ###
### helper global ###
### helper global ###
def escaper():
    try:
        driver.switch_to.active_element.send_keys(Keys.ESCAPE)
    except Exception:
        try:
            ActionChains(driver).send_keys(Keys.ESCAPE).perform()
        except Exception:
            pass

def make_stopper(should_stop_func, update_log, escaper=None, set_runtime_status=None):
    def _stopper():
        if should_stop_func():
            update_log("⛔ Proses entri dihentikan oleh pengguna.")
            if set_runtime_status:
                set_runtime_status("idle", "error")
            if escaper:
                try:
                    escaper()
                except Exception:
                    pass
            return True
        return False
    return _stopper

def zoom_67(driver):
    driver.execute_script("document.body.style.zoom = '67%'")

def zoom_reset(driver):
    driver.execute_script("document.body.style.zoom = ''")
### helper global ###
### helper global ###
### helper global ###

def entri(input_month_name, cleaned_rows, should_stop_func=lambda: False):
    set_runtime_status("busy", "none")
    global driver, excel_file_path
    stopper = make_stopper(should_stop_func, update_log, escaper=escaper, set_runtime_status=set_runtime_status)

    if not driver:
        update_log("ERROR: Browser belum diinisialisasi atau login belum berhasil.")
        set_runtime_status("idle", "error")
        escaper()
        return False

    if not cleaned_rows:
        update_log("❌ Data Excel kosong. Proses dibatalkan.")
        return False
    row_num = 1
    for row in cleaned_rows:
        if stopper():
            set_runtime_status("idle", "error")
            return False

        try:
            # ===== UNPACK BARIS =====
            try:
                tanggal, skp, kegiatan, capaian, linkdukung = row
            except ValueError as e:
                msg = str(e)
                if "too many values to unpack" in msg:
                    update_log("❌ Kolom anda kebanyakan tuh, harusnya 5 kolom aja. Ayo perbaiki dulu.")
                elif "not enough values to unpack" in msg:
                    update_log("❌ Kolom anda kurang tuh, harusnya kan 5 kolom sesuai isian KiPApp. Ayo perbaiki.")
                set_runtime_status("idle", "error")
                return False
            tanggal_str = str(tanggal)
            update_log(f"\n--- Entri baris ke-{row_num} ---")

            if stopper():
                set_runtime_status("idle", "error")
                return False

            # ===== TOMBOL ADD =====
            try:
                WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//button[contains(@class, 'ant-btn-primary') and "
                                   ".//span[contains(text(), 'Add')]]")
                    )
                ).click()
            except (TimeoutException, NoSuchElementException):
                update_log("❌ Wah tombol Add hilang. Sepertinya KiPApp sedang ramai diakses orang se-Indonesia. "
                           "Anda bisa coba nanti saja pas tidak ramai.")
                set_runtime_status("idle", "error")
                return False

            time.sleep(dropdown_delay)

            # ===== DROPDOWN RK =====
            try:
                dropdown_container = WebDriverWait(driver, 20).until(
                    EC.element_to_be_clickable((By.ID, "form-add_rencanaKinerja"))
                )
            except (TimeoutException, NoSuchElementException):
                update_log("❌ Wah kolom RK lama banget termuat. Sepertinya KiPApp sedang ramai diakses orang se-Indonesia. "
                           "Anda bisa coba nanti saja pas tidak ramai.")
                set_runtime_status("idle", "error")
                return False

            time.sleep(rk_delay)
            if stopper():
                set_runtime_status("idle", "error")
                return False

            try:
                dropdown_container.find_element(
                    By.CLASS_NAME, "ant-select-selection__rendered"
                ).click()
            except NoSuchElementException:
                update_log("❌ Wah pilihan RK tidak muncul. Sepertinya KiPApp sedang ramai diakses orang se-Indonesia. "
                           "Anda bisa coba nanti saja pas tidak ramai.")
                set_runtime_status("idle", "error")
                return False

            time.sleep(klikrk_delay)
            search_input = driver.switch_to.active_element
            search_input.send_keys(skp)
            time.sleep(isirk_delay)
            search_input.send_keys(Keys.ARROW_DOWN)
            search_input.send_keys(Keys.ENTER)

            # ===== TANGGAL yang udah include fitur rentang =====
            # ===== TANGGAL yang udah include fitur rentang =====
            # ===== TANGGAL yang udah include fitur rentang =====
            if str(tanggal_str).lower().startswith("range"):
                success = handler_tglrange(driver, tanggal_str, kliktgl_delay, update_log, set_runtime_status)
                if not success:
                    return False
            else:
                input_range_aktif = len(driver.find_elements(
                    By.XPATH, "//input[contains(@placeholder,'Pilih tanggal awal')]"
                )) > 0
                if input_range_aktif:
                    ensure_checkbox_rentang(driver, kliktgl_delay, update_log, should_be_checked=False)

                try:
                    date_input = WebDriverWait(driver, 20).until(
                        EC.element_to_be_clickable(
                            (By.XPATH, "//input[@placeholder='Pilih tanggal']")
                        )
                    )
                except (TimeoutException, NoSuchElementException):
                    update_log("❌ Wah input tanggal hilang. Sepertinya KiPApp sedang ramai diakses orang se-Indonesia. "
                               "Anda bisa coba nanti saja pas tidak ramai.")
                    set_runtime_status("idle", "error")
                    return False

                date_input.click()
                time.sleep(kliktgl_delay)
                active = driver.switch_to.active_element
                ActionChains(driver).move_to_element(active).click()\
                    .send_keys(tanggal_str).send_keys(Keys.ENTER).perform()

            # ===== TANGGAL yang udah include fitur rentang =====
            # ===== TANGGAL yang udah include fitur rentang =====
            # ===== TANGGAL yang udah include fitur rentang =====
            
            # ===== ISI KEGIATAN / CAPAIAN / LINK =====
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.ID, "form-add_kegiatan"))).send_keys(kegiatan)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.ID, "form-add_capaian"))).send_keys(capaian)
            WebDriverWait(driver, 20).until(EC.visibility_of_element_located((By.ID, "form-add_dataDukung"))).send_keys(linkdukung)

            checkbox_label = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, "//label[@class='ant-checkbox-wrapper']//input[@id='form-add_isCapaianSKP']/ancestor::label"))
            )
            if not checkbox_label.find_element(By.ID, "form-add_isCapaianSKP").is_selected():
                checkbox_label.click()

            WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@class, 'ant-btn-primary') and .//span[text()='Save']]"))
            ).click()
            # setelah klik tombol Save
            time.sleep(0.5)  # beri waktu pesan validasi muncul
            explains = driver.find_elements(
                By.CSS_SELECTOR,
                "div.ant-form-explain, div.ant-form-item-explain, div.ant-form-item-explain-error"
            )
            texts = " || ".join((el.text or "").lower() for el in explains)

            # validasi khusus berbasis pesan Ant Design
            if "pilih rencana kinerja" in texts:
                update_log("❌ RK anda belum terisi. Bila RK atau keyword RK anda sudah sesuai, hal ini bisa dikarenakan KiPApp gagal memuat RK. Silakan ulangi proses entri anda dari baris ini.")
                set_runtime_status("idle", "error")
                return False
            elif "pilih tanggal kegiatan" in texts:
                update_log('❌ Tanggal kegiatan anda tidak terisi dengan benar. Pastikan formatnya "yyyy-mm-dd" atau bila tanggal rentang maka "range x-y bln". Perbaiki lalu entri ulang dari baris ini.')
                set_runtime_status("idle", "error")
                return False
            elif "kegiatan minimal 10 karakter." in texts:
                update_log('❌ Kegiatan anda kurang dari 10 karakter. Perbaiki kegiatan, lalu ulang entri dari baris ini.')
                set_runtime_status("idle", "error")
                return False
            elif "capaian minimal 10 karakter." in texts:
                update_log('❌ Capaian anda kurang dari 10 karakter. Perbaiki capaian, lalu ulang entri dari baris ini.')
                set_runtime_status("idle", "error")
                return False
            elif "pilih jam mulai" in texts:
                update_log('❌ Jam mulai anda gagal terisi. Pastikan formatnya hh:mm dengan menit kelipatan 15, lalu ulang entri dari baris ini.')
                set_runtime_status("idle", "error")
                return False
            elif "pilih jam selesai" in texts:
                update_log('❌ Jam selesai anda gagal terisi. Pastikan formatnya hh:mm dengan menit kelipatan 15, lalu ulang entri dari baris ini.')
                set_runtime_status("idle", "error")
                return False
            elif "format harus url" in texts:
                update_log('❌ Format link bukti anda bukan URL. Silakan perbaiki, lalu ulang entri dari baris ini.')
                set_runtime_status("idle", "error")
                return False
            # jika tidak ada pesan error khusus, lanjut ke cek notifikasi berhasil

            # CEK NOTIFIKASI BERHASIL
            try:
                WebDriverWait(driver, 5).until(
                    lambda d: any(
                        "kegiatan baru berhasil ditambahkan" in (el.text or "").lower()
                        for el in d.find_elements(By.CSS_SELECTOR, "div.ant-notification-notice-description")
                    )
                )
            except:
                update_log(f"❌ Formulir gagal disimpan karena satu atau beberapa kolom tidak sesuai kriteria isian KiPApp. Silakan periksa isian baris anda yang ini, mungkin ada kesalahan isi?")
                set_runtime_status("idle", "error")                    
                return False

            time.sleep(submit_delay)
            update_log(f"✅ Baris ke-{row_num} berhasil dientri.")
            if row_num % 5 == 0:
                time.sleep(jeda_delay)

            # JANGAN return di sini, biar lanjut ke baris berikutnya
            row_num += 1

        except Exception as e:
            update_log(f"❌ Terjadi kesalahan saat proses entri baris ke-{row_num}. Pesan eror:{e}")
            set_runtime_status("idle", "error")
            return False
    set_runtime_status("idle", "success")
    return True

def set_dropdown_delay(val): global dropdown_delay; dropdown_delay = val
def set_rk_delay(val):       global rk_delay; rk_delay = val
def set_klikrk_delay(val):  global klikrk_delay; klikrk_delay = val
def set_isirk_delay(val):   global isirk_delay; isirk_delay = val
def set_kliktgl_delay(val): global kliktgl_delay; kliktgl_delay = val
def set_isitgl_delay(val):  global isitgl_delay; isitgl_delay = val
def set_submit_delay(val):   global submit_delay; submit_delay = val
def set_jeda_delay(val):     global jeda_delay; jeda_delay = val
def reset_all_delays_to_default():
    set_dropdown_delay(DEFAULT_DROPDOWN_DELAY)
    set_rk_delay(DEFAULT_RK_DELAY)
    set_klikrk_delay(DEFAULT_KLIKRK_DELAY)
    set_isirk_delay(DEFAULT_ISIRK_DELAY)
    set_kliktgl_delay(DEFAULT_KLIKTGL_DELAY)
    set_isitgl_delay(DEFAULT_ISITGL_DELAY)
    set_submit_delay(DEFAULT_SUBMIT_DELAY)
    set_jeda_delay(DEFAULT_JEDA_DELAY)

def init_browser_and_login(username, password, should_stop_func=lambda: False):
    set_runtime_status("busy", "none")
    global driver, temp_user_data_dir
    stopper = make_stopper(should_stop_func, update_log, escaper=escaper, set_runtime_status=set_runtime_status)
    update_log("Memulai inisialisasi browser dan login...")

    if stopper(): return False

    try:
        service = Service(ChromeDriverManager().install())
        options = Options()
        options.binary_location = config.get("chrome_path")
        time.sleep(0.5)

        temp_user_data_dir = tempfile.mkdtemp()
        options.add_argument(f"--user-data-dir={temp_user_data_dir}")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("--start-maximized")
        options.add_experimental_option("prefs", {"profile.default_content_setting_values.notifications": 2})
        time.sleep(0.5)
        driver = webdriver.Chrome(service=service, options=options)
        
        time.sleep(1)
        
        if stopper():
            update_log("⛔ Proses entri dihentikan sebelum membuka halaman login.")
            driver.quit()
            shutil.rmtree(temp_user_data_dir, ignore_errors=True)
            driver = None
            temp_user_data_dir = None
            return False

        driver.get("https://kipapp.bps.go.id/#/auth/login")
        

        if stopper():
            update_log("⛔ Proses entri dihentikan sebelum klik login.")
            driver.quit()
            shutil.rmtree(temp_user_data_dir, ignore_errors=True)
            driver = None
            temp_user_data_dir = None
            return False

        WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(., 'Login SSO')]"))
        ).click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "username"))
        ).send_keys(username)
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "password"))
        ).send_keys(password)

        if stopper():
            update_log("⛔ Proses entri dihentikan sebelum menekan tombol login.")
            driver.quit()
            shutil.rmtree(temp_user_data_dir, ignore_errors=True)
            driver = None
            temp_user_data_dir = None
            return False

        WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.ID, "kc-login"))
        ).click()

        # Setelah klik tombol login
        # —————— CEK INVALID TANPA THROW ——————
        invalid_elems = driver.find_elements(
            By.XPATH, "//span[@class='kc-feedback-text' and contains(text(), 'Invalid username or password')]"
        )
        if invalid_elems:
            update_log("❌ Perbaiki username atau password anda, lalu lanjutkan login.")
            set_runtime_status("idle", "error")
            return True  # biarkan browser tetap terbuka

        # —————— TUNGGU SALAH SATU KONDISI: HOME / OTP / INVALID ——————
        def any_state(d):
            if "kipapp.bps.go.id/#/home" in d.current_url:
                return "HOME"
            if d.find_elements(By.XPATH, "//*[@id='otp' or @name='otp' or contains(@id,'otp')]"):
                return "OTP"
            if d.find_elements(By.XPATH, "//span[@class='kc-feedback-text' and contains(text(), 'Invalid username or password')]"):
                return "INVALID"
            return False

        state = WebDriverWait(driver, 60).until(any_state)

        if state == "HOME":
            update_log("✅ Login berhasil. Browser dibiarkan terbuka.")
            set_runtime_status("idle", "success")
            return True

        if state == "OTP":
            update_log("✅ Login berhasil. Silakan isi OTP, lanjutkan ke beranda dan tutup semua popup.")
            set_runtime_status("idle", "success")
            return True

        # state == "INVALID"
        update_log("❌ Perbaiki username atau password anda, lalu lanjutkan login.")
        set_runtime_status("idle", "error")
        return True

    except Exception as e:
        msg = str(e).lower()
        if "no chrome binary" in msg:
            update_log("❌ Chrome tidak ditemukan. Atur lokasi Chrome manual di opsi (pojok kanan atas).")
        else:
            update_log("❌ Browser mengalami kendala. Silakan cek koneksi atau coba ulang.")

        # Tutup browser hanya jika benar-benar pada fase inisialisasi awal gagal.
        if driver is None:
            # bersihkan temp jika belum ada sesi yang perlu dipertahankan
            if temp_user_data_dir and os.path.exists(temp_user_data_dir):
                shutil.rmtree(temp_user_data_dir, ignore_errors=True)
                temp_user_data_dir = None

        return False

def close_browser():
    set_runtime_status("busy", "none")
    global driver, temp_user_data_dir
    if driver:
        try:
            driver.quit()
            update_log("Browser berhasil ditutup.")
        except Exception as e:
            update_log(f"Error saat menutup browser: {e}")
        finally:
            driver = None
            if temp_user_data_dir and os.path.exists(temp_user_data_dir):
                shutil.rmtree(temp_user_data_dir, ignore_errors=True)
    else:
        update_log("Tidak ada browser Selenium yang aktif untuk ditutup.")

# tombol restart
def restart_application(master_window):
    close_browser()  # pastikan browser ditutup
    try:
        master_window.destroy()
    except Exception as e:
        update_log(f"❗ Gagal destroy window utama: {e}")
    os.execl(sys.executable, sys.executable, *sys.argv)

def hapus_baris_skp():
    set_runtime_status("busy", "none")
    global driver
    if not driver:
        update_log("ERROR: Browser belum diinisialisasi.")
        set_runtime_status("idle", "error")
        return False

    zoom_67(driver)
    try:
        update_log("Mulai iterasi penghapusan baris SKP...")

        while True:
            aksi_buttons = driver.find_elements(By.XPATH, "//button[contains(@class, 'ant-btn') and contains(@class, 'ant-dropdown-trigger') and contains(., 'Aksi')]")
            if len(aksi_buttons) < 2:
                # update_log("Tidak ada tombol Aksi[1] lagi, selesai.")
                update_log("Tidak ada SKP aktif lagi terdeteksi.")
                # break
                set_runtime_status("idle", "success")
                zoom_reset(driver)
                return False

            try:
                aksi_buttons[1].click()
                time.sleep(0.5)

                delete_item = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//li[contains(@class, 'ant-dropdown-menu-item') and contains(., 'Delete')]"))
                )
                delete_item.click()

                # Tunggu dan klik tombol "Yes"
                yes_button = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[.='Yes']"))
                )
                time.sleep(0.5)
                yes_button.click()
                update_log("Baris berhasil dihapus.")

            except Exception as e:
                update_log(f"❌ ERROR saat menghapus baris SKP: tombol menghilang atau halaman berpindah.")
                set_runtime_status("idle", "error")
                zoom_reset(driver)
                return False  # Keluar dari loop jika ada error

            time.sleep(2)  # jeda antar iterasi

    except Exception as e:
        update_log(f"❌ ERROR saat menghapus baris SKP: tombol menghilang atau halaman berpindah.")
        set_runtime_status("idle", "error")
        zoom_reset(driver)
        return False

def delete_rk_kosong():
    set_runtime_status("busy", "none")
    global driver
    if not driver:
        update_log("❌ Browser belum diinisialisasi.")
        set_runtime_status("idle", "error")
        return False
    zoom_67(driver)
    try:
        update_log("🔍 Mencari baris dengan RK 0 dan klik tombol Aksi...")

        while True:
            try:
                # Cari baris <tr> pertama dengan <span>0 di tombol circle
                target_row = driver.find_element(By.XPATH,
                    "//tr[contains(@class, 'ant-table-row') and contains(@class, 'ant-table-row-level-0')]" +
                    "[.//td[contains(@class, 'ant-table-column-has-actions')]//button[contains(@class, 'ant-btn-circle')]//span[normalize-space(.)='0']]"
                )
                rkempty = target_row.find_element(By.XPATH, ".//td[4]").text.strip()

            except:
                update_log("✅ Tidak ada RK bernilai 0 yang tersisa.")
                zoom_reset(driver)
                return True

            # Dalam baris yang sama, cari tombol Aksi
            aksi_button = target_row.find_element(By.XPATH,
                ".//td[contains(@class, 'ant-table-row-cell-break-word')]//button[contains(@class, 'ant-dropdown-trigger')]//span[normalize-space(text())='Aksi']/.."
            )
            aksi_button.click()
            time.sleep(0.5)

            delete_item = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//li[contains(@class, 'ant-dropdown-menu-item') and contains(., 'Delete')]"))
            )
            delete_item.click()
            time.sleep(0.5)
            # Tunggu dan klik tombol "Yes"
            yes_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//button[.='Yes']"))
            )
            time.sleep(0.5)
            yes_button.click()
            update_log("Baris berhasil dihapus.")

            update_log(f"🗑️ Baris dengan RK \"{rkempty}\" dan bukti dukung nol berhasil dihapus.")

            time.sleep(3)

    except Exception as e:
        update_log(f"❌ ERROR saat menghapus RK kosong: tombol menghilang atau halaman berpindah.")
        zoom_reset(driver)
        return False

# Load credential.txt
def load_credentials(file_path="credential.txt"):
    set_runtime_status("busy", "none")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            if len(lines) >= 2:
                username = lines[0].strip()
                password = lines[1].strip()
                set_runtime_status("idle", "success")
                return True, username, password
            else:
                set_runtime_status("idle", "error")
                return False, None, None
    except FileNotFoundError:
        set_runtime_status("idle", "error")
        return False, None, None
    except Exception as e:
        update_log(f"❌ Gagal membaca credential.txt: {e}")
        set_runtime_status("idle", "error")
        return False, None, None

# load api
def load_api_keys(file_path="api.txt", full=False):
    set_runtime_status("busy", "none")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            lines = [line.strip() for line in lines if line.strip()]
            if len(lines) >= 2:
                api_key = lines[0]
                api_secret = lines[1]
                drive_path = lines[2] if len(lines) >= 3 else ""
                set_runtime_status("idle", "success")
                if full:
                    return True, api_key, api_secret, drive_path
                return True, api_key, api_secret
            else:
                set_runtime_status("idle", "error")
                return False, None, None, None if full else (False, None, None)
    except FileNotFoundError:
        set_runtime_status("idle", "error")
        return False, None, None, None if full else (False, None, None)
    except Exception as e:
        update_log(f"❌ Gagal membaca api.txt: {e}")
        set_runtime_status("idle", "error")
        return False, None, None, None if full else (False, None, None)

# load skp
def method_helper(source, mode):
    set_runtime_status("busy", "none")
    """
    mode: "Excel Lokal", "Gsheet" atau "Excel BPS"
    source: path file (mode=Excel Lokal) atau URL (mode=Gsheet)
    return: (ws, header:list[str], colmap:dict[str,int]) atau (None, [], {})
    """
    global excel_file_path
    try:
        if mode == "Gsheet":
            url = source
            if not url or not url.strip():
                update_log("❌ Link belum diisi.")
                return None, [], {}
            if "docs.google.com/spreadsheets" in url and "/edit" in url:
                sheet_id = url.split("/d/")[1].split("/")[0]
                url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=xlsx"
            r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=30)
            r.raise_for_status()
            wb = load_workbook(BytesIO(r.content))
            excel_file_path = url

        elif mode == "Excel BPS":
            url = source
            if not url or not url.strip():
                update_log("❌ Link belum diisi.")
                return None, [], {}
            r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=30)
            r.raise_for_status()
            wb = load_workbook(BytesIO(r.content))
            excel_file_path = url

        else:  # "Excel Lokal"
            wb = load_workbook(source)
            excel_file_path = source

        ws = wb.active
        header = [cell.value for cell in ws[1]]

        empty_cols = [i + 1 for i, h in enumerate(header) if h is None or str(h).strip() == ""]
        if not header or empty_cols:
            if empty_cols:
                update_log(f"❌ Ada header yang kosong pada kolom: {empty_cols}. Import gagal.")
            else:
                update_log("❌ Baris header kosong. Import gagal.")
            set_runtime_status("idle", "error")
            return None, [], {}

        colmap = {h.lower(): i for i, h in enumerate(header) if h}
        set_runtime_status("idle", "success")
        return ws, header, colmap

    except Exception as e:
        update_log(f"❌ Gagal membuka file: {e}")
        return None, [], {}

# drive bps handler
# drive bps handler
# drive bps handler
BASE_URL = "https://drive.bps.go.id"
def get_auth():
    return globals().get("USERNAME", ""), globals().get("PASSWORD", "")
def get_headers_ocs():
    return {"OCS-APIRequest": "true"}

def get_base_webdav():
    return f"{BASE_URL}/remote.php/dav/files/{globals().get('USERNAME', '')}{globals().get('ROOT_FOLDER', '')}"

def get_session():
    session = requests.Session()
    session.auth = get_auth()
    return session

def propfind(url, depth="1"):
    headers = {"Depth": depth}
    res = requests.request("PROPFIND", url, auth=get_auth()
    , headers=headers)
    res.raise_for_status()
    return ET.fromstring(res.content)

def list_subfolders():
    username = globals().get("USERNAME", "")
    root_folder = globals().get("ROOT_FOLDER", "")
    root_xml = propfind(get_base_webdav(), depth="1")
    folders = []
    for resp in root_xml.findall("{DAV:}response"):
        href = resp.find("{DAV:}href").text
        if href.endswith("/") and href != f"/remote.php/dav/files/{username}{root_folder}/":
            rel_path = href.split(f"/remote.php/dav/files/{username}")[-1]
            folders.append(rel_path)
    return folders

def list_files_in_folder(folder_path):
    username = globals().get("USERNAME", "")
    full_url = f"{BASE_URL}/remote.php/dav/files/{username}{folder_path}"
    xml = propfind(full_url, depth="infinity")
    files = []
    for resp in xml.findall("{DAV:}response"):
        href = resp.find("{DAV:}href").text
        if not href.endswith("/"):
            rel_path = href.split(f"/remote.php/dav/files/{username}")[-1]
            files.append(rel_path)
    return files

def create_public_link(path):
    path = urllib.parse.unquote(path)
    api_url = f"{BASE_URL}/ocs/v2.php/apps/files_sharing/api/v1/shares"
    headers = get_headers_ocs()
    data = {
        "path": path,
        "shareType": 3,
        "permissions": 1
    }
    res = requests.post(api_url, auth=get_auth()
    , headers=headers, data=data)
    res.raise_for_status()
    xml = ET.fromstring(res.content)
    if xml.find(".//statuscode").text != "100":
        return None
    return xml.find(".//url").text

def get_or_create_public_link(path):
    clean_path = urllib.parse.unquote(path)
    encoded_path = urllib.parse.quote(clean_path)
    get_url = f"{BASE_URL}/ocs/v2.php/apps/files_sharing/api/v1/shares?path={encoded_path}"
    headers = get_headers_ocs()
    res_get = requests.get(get_url, auth=get_auth()
    , headers=headers)
    res_get.raise_for_status()
    xml_get = ET.fromstring(res_get.content)
    url_el = xml_get.find(".//url")
    if url_el is not None:
        return url_el.text
    post_url = f"{BASE_URL}/ocs/v2.php/apps/files_sharing/api/v1/shares"
    data = {
        "path": clean_path,
        "shareType": 3,
        "permissions": 1
    }
    res_post = requests.post(post_url, auth=get_auth()
    , headers=headers, data=data)
    res_post.raise_for_status()
    xml_post = ET.fromstring(res_post.content)
    url_new = xml_post.find(".//url")
    return url_new.text if url_new is not None else None

_link_cache = None

def cari_link():
    set_runtime_status("busy", "none")
    global _link_cache, ws
    if _link_cache is not None:
        return _link_cache

    username = globals().get("USERNAME", "")
    xml = propfind(get_base_webdav(), depth="infinity")
    files = []
    for resp in xml.findall("{DAV:}response"):
        href = resp.find("{DAV:}href").text
        if not href.endswith("/"):
            rel_path = href.split(f"/remote.php/dav/files/{username}")[-1]
            files.append(rel_path)

    update_log(f"\U0001F4C4 Total file ditemukan: {len(files)}\n")

    links = []
    total_shared = 0
    for file in files:
        update_log(f"\U0001F517 Menangani file: {file}")
        link = get_or_create_public_link(file)
        if link:
            update_log(f"     ✅ Link publik: {link}")
            total_shared += 1
            links.append((os.path.basename(file), link))
        else:
            update_log(f"     ❌ Gagal membuat/ambil link.")

    update_log(f"\n✅ Selesai. Total file dengan link publik aktif: {total_shared}")
    set_runtime_status("idle", "success")
    _link_cache = links
    return links

def extract_link(nama_file: str):
    """
    Cari file di Nextcloud yang cocok dengan nama_file,
    lalu kembalikan link publiknya.
    """
    if not nama_file:
        return ""

    try:
        # CEK KREDENSIAL
        if not globals().get("USERNAME") or not globals().get("PASSWORD") or not globals().get("ROOT_FOLDER"):
            raise ValueError("API key, API secret, atau path Drive BPS belum diisi.")
            set_runtime_status("idle", "error")

        username = globals().get("USERNAME", "")
        base_url = get_base_webdav()
        xml = propfind(base_url, depth="infinity")

        for resp in xml.findall("{DAV:}response"):
            href = resp.find("{DAV:}href").text
            if href.endswith("/"):
                continue

            filename = os.path.basename(urllib.parse.unquote(href)).lower()
            if nama_file.lower() in filename:
                relative_path = href.split(f"/remote.php/dav/files/{username}")[-1]

                link = get_or_create_public_link(relative_path)
                # msg = f"🔗 mengambil/membuat link '{link}' untuk '{nama_file}'"
                # log_extract_result.append(msg)
                # update_log(msg)
                return link
# hehe
        log_extract_result.append(f"❌ tidak ditemukan file bernama '{nama_file}'. nama file tidak diganti")
        return nama_file

    except ValueError as ve:
        update_log(f"❌ {ve}")
        raise

    except requests.exceptions.HTTPError:
        update_log("❌ Gagal mengakses Drive BPS: Unauthorized atau koneksi bermasalah.")
        set_runtime_status("idle", "error")
        raise

    except Exception as e:
        update_log(f"❌ Error tak terduga di extract_link: {e}")
        set_runtime_status("idle", "error")
        raise
# drive bps handler
# drive bps handler
# drive bps handler

# def import_data(source, input_month_name, do_cleaning=True, filter_by_month=True, mode="Excel Lokal"):
def import_data(source, mode="Excel Lokal"):
    set_runtime_status("busy", "none")
    """
    Satu pintu import:
      - mode="Excel Lokal"  -> source = path file
      - mode="Gsheet"-> source = URL (boleh mentah /edit, akan dinormalisasi)
    Return: (success:bool, headers:list[str], rows:list[list])
    """
    # update_log(f"Mode cleaning: {do_cleaning}, filter bulan: {filter_by_month}")
    global ws, session, ROOT_FOLDER
    ws, header, colmap = method_helper(source, mode)
    if ws is None:
        set_runtime_status("idle", "error")
        return False, [], []

    # validasi & siapkan filter bulan
    bulan_filter = None
    # if filter_by_month:
    #     if not input_month_name:
    #         update_log("ERROR: Nama bulan kosong padahal filter bulan aktif.")
    #         set_runtime_status("idle", "error")
    #         return False, [], []
    #     bulan_filter = bulan_map.get(str(input_month_name).strip().lower())
    #     if not bulan_filter:
    #         update_log(f"ERROR: Nama bulan tidak valid: {input_month_name}")
    #         set_runtime_status("idle", "error")
    #         return False, [], []

    # if do_cleaning:
    #     # return cleaning(ws, colmap, filter_by_month, bulan_filter)
    #     return cleaning(ws, colmap, filter_by_month, bulan_filter, update_log=update_log, set_runtime_status=set_runtime_status)

    # do_cleaning == False (impor mentah)
    try:
        # result_rows = filter_month(ws, colmap, bulan_filter, set_runtime_status=set_runtime_status) if filter_by_month else [
            # tuple(row) for row in ws.iter_rows(min_row=2, values_only=True)
        result_rows = [list(r) for r in ws.iter_rows(min_row=2, values_only=True)]
        # ]
            # --- Deteksi kolom tanggal berbasis isi baris pertama (tanpa aliases) ---
        # Ambil satu baris sampel pertama yang tidak kosong
        try:
            sample = next((r for r in result_rows if r and any(c is not None and str(c).strip() != "" for c in r)), None)
            if sample:
                t_idx = None
                for i, v in enumerate(sample):
                    # Jika baris pertama berisi datetime/date, atau string dengan pola "tanggal jam"
                    if isinstance(v, datetime.datetime) or isinstance(v, datetime.date):
                        t_idx = i
                        break
                    if isinstance(v, str) and (" " in v and ":" in v):
                        # contoh "2025-10-01 00:00:00" -> terdeteksi
                        t_idx = i
                        break

                # Normalisasi seluruh kolom terdeteksi ke "YYYY-MM-DD"
                if t_idx is not None:
                    for r in result_rows:
                        v = r[t_idx]
                        if isinstance(v, datetime.datetime):
                            r[t_idx] = v.date().isoformat()
                        elif isinstance(v, datetime.date):
                            r[t_idx] = v.isoformat()
                        elif isinstance(v, str) and " " in v and ":" in v:
                            r[t_idx] = v.split(" ")[0]
        except Exception:
            # diam jika tidak bisa dinormalisasi
            pass

    except KeyError as e:
        update_log(f"❌ Gagal: tidak ada kolom {e}. Matikan checklist \"Filter Bulan\" bila tidak ada kolom tersebut.")
        set_runtime_status("idle", "error")
        return False, [], []
    # hapus None
    result_rows = [r for r in result_rows if any(c is not None for c in r)]
    update_log(f"✅ Berhasil diimpor. Jumlah baris: {len(result_rows)}")
    set_runtime_status("idle", "success")
    return True, header, result_rows

### driver handler ###
### driver handler ###
### driver handler ###
_last_driver_error_type = None  # "disconnected" | "closed" | None
def _classify_wd_exception(exc: WebDriverException) -> str:
    """
    Kembalikan 'disconnected' jika sesi Selenium putus (browser mungkin masih terbuka),
    'closed' jika indikasinya jendela/browser memang tertutup,
    default 'closed' bila ragu.
    """
    msg = (str(exc) or "").lower()
    # Indikasi sesi putus/devtools disconnect
    disconnected_keys = (
        "disconnected:", "not connected to devtools",
        "chrome not reachable", "invalid session id",
        "target closed", "webview not found", "session deleted",
    )
    if any(k in msg for k in disconnected_keys):
        return "disconnected"

    closed_keys = (
        "no such window", "failed to check if window was closed",
        "webview not available", "unable to find window",
    )
    if any(k in msg for k in closed_keys):
        return "closed"

    # Jika tidak cocok apa pun, anggap closed (lebih aman untuk recovery)
    return "closed"

def get_last_driver_error_type():
    return _last_driver_error_type
def get_driver():
    global driver, _last_driver_error_type
    if driver is not None:
        try:
            _ = driver.title  # ping ringan
            _last_driver_error_type = None
            return driver
        except WebDriverException as e:
            kind = _classify_wd_exception(e)
            _last_driver_error_type = kind
            if kind == "disconnected":
                update_log("⚠️ Sesi Selenium terputus dari browser (browser kemungkinan masih terbuka). Silakan re-inisialisasi koneksi.")
            else:
                update_log("⚠️ Browser tidak valid/tertutup. Silakan inisialisasi ulang.")
            driver = None
    return None
### driver handler ###
### driver handler ###
### driver handler ###