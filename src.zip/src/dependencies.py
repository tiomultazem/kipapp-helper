import subprocess
import sys

_install_has_run = False

DEFAULT_PACKAGES = [
    "openpyxl",
    "Pillow",
    "selenium",
    "webdriver-manager",
    "tabulate",
    # "ttkbootstrap",  # Tambahkan jika dibutuhkan
]

def ensure_installed(packages, verbose=False):
    for pkg in packages:
        try:
            # Pillow perlu pengecualian karena modulenya bernama PIL
            if pkg == "Pillow":
                __import__("PIL")
            else:
                __import__(pkg)
        except ImportError:
            if verbose:
                print(f"📦 Installing missing package: {pkg}")
            subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])

def install_all(skip_if_frozen=True, packages=None, verbose=False):
    global _install_has_run
    if _install_has_run:
        return
    _install_has_run = True

    if skip_if_frozen and getattr(sys, 'frozen', False):
        return  # ⛔ Lewatkan kalau dari PyInstaller

    if packages is None:
        packages = DEFAULT_PACKAGES

    ensure_installed(packages, verbose=verbose)
