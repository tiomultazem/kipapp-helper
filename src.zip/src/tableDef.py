# tableDef.py
import tkinter as tk
from tkinter import ttk

last_checked_index = None

def toggle_all_checkboxes(tree, checkbox_all_state):
    checkbox_all_state["checked"] = not checkbox_all_state["checked"]
    new_val = "☑" if checkbox_all_state["checked"] else "☐"
    for item in tree.get_children():
        tree.set(item, "__checked__", new_val)

def update_treeview_data(tree, gui, checkbox_all_state, sort_by_column):
    # Perbarui kolom heading jika headers berubah
    current_cols = tree["columns"]
    # updated_cols = ["__checked__"] + gui.cleaned_headers
    updated_cols = ["__checked__", "__no__"] + gui.cleaned_headers

    # if current_cols != tuple(updated_cols):
    #     tree.config(columns=updated_cols)
    #     tree.heading("__checked__", text="✓", command=lambda: toggle_all_checkboxes(tree, checkbox_all_state))
    #     tree.column("__checked__", width=30, anchor="center")
    #     for col in gui.cleaned_headers:
    #         tree.heading(col, text=col, command=lambda c=col: sort_by_column(c))
    #         tree.column(col, anchor="w", width=150)

    if current_cols != tuple(updated_cols):
        tree.config(columns=updated_cols)

        tree.heading("__checked__", text="✓",
                    command=lambda: toggle_all_checkboxes(tree, checkbox_all_state))
        tree.column("__checked__", width=30, anchor="center")

        tree.heading("__no__", text="No")
        tree.column("__no__", width=50, anchor="center")

        for col in gui.cleaned_headers:
            tree.heading(col, text=col, command=lambda c=col: sort_by_column(c))
            tree.column(col, anchor="w", width=150)
    # Kosongkan semua baris dulu
    for i in tree.get_children():
        tree.delete(i)

    # Tambah data baru
    for idx, row in enumerate(gui.cleaned_data, start=1):
        tree.insert("", "end", values=["☐", idx] + list(row))

def sort_by_column(tree, col, sort_directions):
    items = [(tree.set(k, col), k) for k in tree.get_children()]
    reverse = sort_directions.get(col, False)
    sort_directions[col] = not reverse
    try:
        items.sort(key=lambda t: float(t[0]) if t[0].replace('.', '', 1).isdigit() else t[0], reverse=reverse)
    except Exception:
        items.sort(key=lambda t: t[0], reverse=reverse)
    for index, (_, k) in enumerate(items):
        tree.move(k, '', index)

def on_row_click(event, tree):
    global last_checked_index

    item = tree.identify_row(event.y)
    col = tree.identify_column(event.x)
    if not item or col != '#1':
        return

    all_items = tree.get_children()
    idx = all_items.index(item)
    current = tree.set(item, "__checked__")
    new_val = "☑" if current != "☑" else "☐"

    # --- jika Shift ditekan dan ada klik sebelumnya ---
    if (event.state & 0x0001) and last_checked_index is not None:
        start = min(last_checked_index, idx)
        end = max(last_checked_index, idx)
        for i in range(start, end + 1):
            tree.set(all_items[i], "__checked__", new_val)
    else:
        # toggle normal
        tree.set(item, "__checked__", new_val)
        last_checked_index = idx

def on_hover(event, tree, gui):
    item = tree.identify_row(event.y)
    hover_color = "#64ebfa" if gui.dark_mode_enabled else "#d0e9ff"
    tree.tag_configure("hover", background=hover_color)
    for i in tree.get_children():
        tree.item(i, tags=())
    if item:
        tree.item(item, tags=("hover",))

def hapus_baris_tercentang(tree, gui):
    selected_indices = []
    for i, item in enumerate(tree.get_children()):
        if tree.set(item, "__checked__") == "☑":
            selected_indices.append(i)
            tree.delete(item)
    gui.cleaned_data = [r for i, r in enumerate(gui.cleaned_data) if i not in selected_indices]

# === PEMINDAHAN FUNGSI EDIT & DATA ===

# def save_tree_to_cleaned_data(tree, gui):
#     new_data = []
#     for item in tree.get_children():
#         row = tree.item(item)['values'][1:]  # tanpa kolom checkbox
#         new_data.append(list(row))
#     gui.cleaned_data = new_data

def save_tree_to_cleaned_data(tree, gui):
    new_data = []
    for item in tree.get_children():
        # values: [__checked__, __no__, col1, col2, ...]
        row = tree.item(item)['values'][2:]  # buang checkbox + nomor
        new_data.append(list(row))
    gui.cleaned_data = new_data

def toggle_edit_mode(tree, btn_toggle_edit, edit_mode_state, gui):
    edit_mode_state["active"] = not edit_mode_state["active"]
    editing = edit_mode_state["active"]
    btn_toggle_edit.config(style="Yellow.TButton" if editing else "Blue.TButton")
    if editing:
        tree.bind("<Double-1>", lambda e: start_cell_edit(e, tree, gui, edit_mode_state))
    else:
        tree.unbind("<Double-1>")
        save_tree_to_cleaned_data(tree, gui)

def start_cell_edit(event, tree, gui, edit_mode_state):
    if not edit_mode_state.get("active"):
        return
    region = tree.identify("region", event.x, event.y)
    if region != "cell":
        return
    row_id = tree.identify_row(event.y)
    col_id = tree.identify_column(event.x)
    # col_index = int(col_id[1:]) - 1
    # if col_index == 0:
    #     return  # abaikan kolom checkbox
    # open_editor_at(tree, gui, row_id, col_index)
    col_index = int(col_id[1:]) - 1
    # 0 = __checked__, 1 = __no__
    if col_index in (0, 1):
        return
    open_editor_at(tree, gui, row_id, col_index)


def start_cell_edit_direct(tree, gui, row_id, col_index):
    open_editor_at(tree, gui, row_id, col_index)

def open_editor_at(tree, gui, row_id, col_index):
    # col_index = max(1, min(len(gui.cleaned_headers), col_index))
    # col_id = f"#{col_index + 1}"
    # bbox = tree.bbox(row_id, col_id)
    # if not bbox:
    #     return
    # x, y, w, h = bbox
    # value = tree.set(row_id, gui.cleaned_headers[col_index - 1])
    # col_index di sini adalah index kolom global (0=__checked__, 1=__no__, 2=kolom data pertama)
    # Batasi agar hanya ke kolom data
    col_index = max(2, min(len(gui.cleaned_headers) + 1, col_index))

    col_id = f"#{col_index + 1}"
    bbox = tree.bbox(row_id, col_id)
    if not bbox:
        return
    x, y, w, h = bbox

    data_col_idx = col_index - 2  # mapping ke index gui.cleaned_headers
    header_name = gui.cleaned_headers[data_col_idx]
    value = tree.set(row_id, header_name)

    editor = ttk.Entry(tree)
    editor.insert(0, value)
    editor.place(x=x, y=y, width=w, height=h)
    editor.focus_set()

    def save_and_destroy():
        if editor.winfo_exists():
            tree.set(row_id, header_name, editor.get())
            editor.destroy()

    def move_focus(delta_row=0, delta_col=0):
        save_and_destroy()
        rows = tree.get_children()
        if row_id not in rows:
            return
        r_idx = rows.index(row_id)
        new_r_idx = max(0, min(len(rows) - 1, r_idx + delta_row))
        # new_c_idx = max(1, min(len(gui.cleaned_headers), col_index + delta_col))
        # kolom data: 2 .. len(gui.cleaned_headers)+1
        new_c_idx = max(2, min(len(gui.cleaned_headers) + 1, col_index + delta_col))
        new_row = rows[new_r_idx]
        open_editor_at(tree, gui, new_row, new_c_idx)

    def on_up(event):
        move_focus(-1, 0);  return "break"

    def on_down(event):
        move_focus(1, 0);   return "break"

    def on_left(event):
        # Kalau ini kolom data pertama, jangan pindah ke sel kiri
        if data_col_idx == 0:
            return  # biarkan Entry handle sendiri, tidak looping
        if editor.index(tk.INSERT) == 0:
            move_focus(0, -1);  return "break"

    def on_right(event):
        if editor.index(tk.INSERT) == len(editor.get()):
            move_focus(0, 1);   return "break"

    def on_return(event):
        move_focus(1, 0);   return "break"

    def on_focus_out(event):
        save_and_destroy()

    editor.bind("<Up>", on_up)
    editor.bind("<Down>", on_down)
    editor.bind("<Left>", on_left)
    editor.bind("<Right>", on_right)
    editor.bind("<Return>", on_return)
    editor.bind("<FocusOut>", on_focus_out)

def tambah_baris_kosong(tree, gui, checkbox_all_state, sort_directions, edit_mode_state=None):
    kosong = ["" for _ in gui.cleaned_headers]
    gui.cleaned_data.append(kosong)
    update_treeview_data(
        tree, gui, checkbox_all_state,
        lambda c: sort_by_column(tree, c, sort_directions)
    )
    if edit_mode_state and edit_mode_state.get("active"):
        row_id = tree.get_children()[-1]
        tree.focus(row_id)
        tree.selection_set(row_id)
        tree.see(row_id)
        start_cell_edit_direct(tree, gui, row_id, 1)