# src/about.py
import tkinter as tk
from tkinter import ttk
import webbrowser
from config import set

def show_about_popup(master, gui):
    popup = tk.Toplevel(master)
    popup.title("Tentang KipApp Helper")
    popup.geometry("420x240")
    popup.transient(master)
    popup.grab_set()

    # Terapkan background & warna berdasarkan dark mode
    if gui.dark_mode_enabled:
        bg_color = "#171717"
        fg_color = "white"
        link_color = "#64ebfa"
    else:
        bg_color = "#f0f0f0"
        fg_color = "black"
        link_color = "blue"

    popup.configure(bg=bg_color)

    def buat_label(master, teks, **opsi):
        return tk.Label(master, text=teks, anchor="w", justify="left", wraplength=400,
                        bg=bg_color, fg=fg_color, **opsi)

    intro_text = "Halo, Pengguna!\n\nUntuk update, kamu bisa clone project di link berikut:"
    buat_label(popup, intro_text).pack(padx=10, pady=(10, 2), anchor="w")

    def buka_git(_): webbrowser.open_new("https://git.bps.go.id/gilangprasetyo/kipapp-helper-dev.git")
    def buka_qna(_): webbrowser.open_new("https://s.bps.go.id/kipapp-helper-qna")

    link1 = tk.Label(popup, text="🌐 git.bps.go.id/gilangprasetyo/kipapp-helper-dev.git",
                     fg=link_color, cursor="hand2", anchor="w", bg=bg_color)
    link1.pack(padx=10, anchor="w")
    link1.bind("<Button-1>", buka_git)

    buat_label(popup, "atau bisa melalui tombol 'Cek Update' di Pengaturan.").pack(padx=10, pady=(6, 2), anchor="w")

    buat_label(popup, "Kamu bisa mengajukan pertanyaan di link berikut:").pack(padx=10, pady=(10, 2), anchor="w")

    link2 = tk.Label(popup, text="❓ s.bps.go.id/kipapp-helper-qna",
                     fg=link_color, cursor="hand2", anchor="w", bg=bg_color)
    link2.pack(padx=10, anchor="w")
    link2.bind("<Button-1>", buka_qna)

    buat_label(popup, "atau lewat WA pribadi juga boleh!").pack(padx=10, pady=(8, 2), anchor="w")

    def tutup(): popup.destroy()

    def jangan_tampilkan_lagi():
        gui.update_log_gui("🔕 About disembunyikan. Anda bisa menampilkannya lagi di ⚙️ Opsi")
        set("hide_about", True)
        popup.destroy()

    btn_frame = tk.Frame(popup, bg=bg_color)
    btn_frame.pack(pady=10)

    # ⛳️ Pakai Kipapp.TButton
    ttk.Button(btn_frame, text="Tutup", command=tutup, style="Plain.TButton").pack(side="left", padx=10)
    ttk.Button(btn_frame, text="Jangan tampilkan lagi", command=jangan_tampilkan_lagi, style="Red.TButton").pack(side="left", padx=10)
