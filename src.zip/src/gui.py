# install dependensi
import dependencies
dependencies.install_all()
from config import get, rel_path, BASE_DIR
from printLogo import print_logo_terminal
import preprocess
import tkinter as tk
from tablePopup import show_excel_as_table
from tkinter import filedialog, messagebox, ttk
import threading
import tableDef as td
import app, theme, settingsPopup, aboutPopup
from PIL import Image, ImageTk
import os
import datetime
import config
from updatePopup import run_updatePopup

class KipappGUI:
    def __init__(self, master):
        style = ttk.Style()
        style.theme_use("clam")
        self.cleaned_data = []  # list of dicts or rows
        self.cleaned_headers = []  # simpan nama kolom
        self.api_key_var = tk.StringVar()
        self.api_secret_var = tk.StringVar()
        self.api_path_var = tk.StringVar()
        self.rename_dir_var = tk.StringVar()

        try:
            import_mode = config.get("import_mode")
        except KeyError:
            import_mode = "Excel Lokal"
            config.set("import_mode", import_mode)

        try:
            cleaning_check = config.get("cleaning")
        except KeyError:
            cleaning_check = False
            config.set("cleaning", cleaning_check)

        try:
            filter_check = config.get("filter")
        except KeyError:
            filter_check = False
            config.set("filter", filter_check)
        try:
            show_log_check = config.get("show_log")
        except KeyError:
            show_log_check = True
            config.set("show_log", show_log_check)

        try:
            frame_cleanup_check = config.get("frame_cleanup")
        except KeyError:
            frame_cleanup_check = False
            config.set("frame_cleanup", frame_cleanup_check)
        try:
            chrome_path = config.get("chrome_path")
        except KeyError:
            chrome_path = ""   # kosong default
            config.set("chrome_path", chrome_path)

        # self.btn_ubah_link = None
        self.import_mode = tk.StringVar(value=import_mode)
        self.cleaning_enabled = tk.BooleanVar(value=cleaning_check)
        self.enable_bulan_filter = tk.BooleanVar(value=filter_check)
        self.show_log = tk.BooleanVar(value=show_log_check)
        self.frame_cleanup = tk.BooleanVar(value=frame_cleanup_check)
        self.cleaning_enabled.trace_add("write", lambda *a: config.set("cleaning", self.cleaning_enabled.get()))
        self.enable_bulan_filter.trace_add("write", lambda *a: config.set("filter", self.enable_bulan_filter.get()))
        self.show_log.trace_add("write", lambda *a: config.set("show_log", self.show_log.get()))
        self.frame_cleanup.trace_add("write", lambda *a: config.set("frame_cleanup", self.frame_cleanup.get()))
        self.should_stop = False
        self.master = master
        self.chrome_path_var = tk.StringVar(value=chrome_path)
        self.chrome_path_var.trace_add("write", lambda *a: config.set("chrome_path", self.chrome_path_var.get()))

        self.delay_dropdown_var = tk.DoubleVar(value=app.dropdown_delay)
        self.delay_rk_var = tk.DoubleVar(value=app.rk_delay)
        self.delay_klikrk_var = tk.DoubleVar(value=app.klikrk_delay)
        self.delay_isirk_var = tk.DoubleVar(value=app.isirk_delay)
        self.delay_kliktgl_var = tk.DoubleVar(value=app.kliktgl_delay)
        self.delay_isitgl_var = tk.DoubleVar(value=app.isitgl_delay)
        self.delay_submit_var = tk.DoubleVar(value=app.submit_delay)
        self.delay_jeda_var = tk.DoubleVar(value=app.jeda_delay)
        self.dark_mode_enabled = get("dark_mode_enabled")

        if not get("hide_about"):
            aboutPopup.show_about_popup(self.master, self)

        master.title("KipApp Helper")

        master.minsize(475, 300)        # Biar ga kekecilan
        master.maxsize(475, 10000)      # Biar tinggi fleksibel, lebar tetap 450
        master.protocol("WM_DELETE_WINDOW", self.on_closing)

        app.set_log_callback(self.update_log_gui)
        self.create_widgets()
        if self.dark_mode_enabled:
            theme.apply_dark(self)
        else:
            theme.apply_light(self)
        # toggle pengaturan
        self.toggle_log_frame()        # untuk sembunyikan/ tampilkan frame log sesuai nilai awal
        self.toggle_frame_cleanup()    # untuk set ke basic/advanced sesuai nilai awal

    def create_widgets(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Blue.TButton", background="#aedff7", padding=(4, 2))
        style.configure("Green.TButton", background="#c9f7cf", padding=(4, 2))
        style.configure("Red.TButton", background="#f9c5c5", padding=(4, 2))
        style.configure("Plain.TButton", background="#f0f0f0", padding=(4, 2))
        style.configure("Yellow.TButton", background="#FFF3B0", padding=(4, 2))
        style.configure("Kipapp.TEntry", foreground="#171717", fieldbackground="#f0f0f0")
        style.configure("Kipapp.TSpinbox", foreground="#171717", fieldbackground="#f0f0f0", background="#f0f0f0")
        style.configure("Kipapp.TEntry", foreground="#171717", fieldbackground="white")
        style.configure("Kipapp.TSpinbox", foreground="#171717", fieldbackground="white", background="white")
        style.configure("TFrame", background="#f0f0f0")
        style.configure("TLabel", background="#f0f0f0", foreground="#171717")
        style.configure("TCheckbutton", background="#f0f0f0", foreground="#171717")
        style.configure("TLabelframe", background="#f0f0f0", foreground="#171717")
        style.configure("TLabelframe.Label", background="#f0f0f0", foreground="#171717")
        style.configure("KiPApp.TCombobox",fieldbackground="#f0f0f0",background="#f0f0f0", foreground="#171717")
        bulan_saat_ini = datetime.date.today().strftime("%B").lower()
        bulan_otomatis = preprocess.bulan_indo_map.get(bulan_saat_ini, "")
        
        header_frame = ttk.Frame(self.master)
        header_frame.pack(padx=8, pady=(10, 0), fill="x")

        # ⬅ Tambahkan logo di sini
        self.logo_img = Image.open(os.path.join(BASE_DIR, "..", "assets", "favicon.ico")).resize((40,40))
        self.logo_img_tk = ImageTk.PhotoImage(self.logo_img)
        self.logo_label = tk.Label(
            header_frame,
            image=self.logo_img_tk,
            bg="white",  # fallback
        )
        self.logo_label.pack(side="left", padx=(0, 6))

        # Toggle Advanced Mode (di kiri)
        toggle_btn = ttk.Checkbutton(
            header_frame,
            text="Cleanup Mode",
            variable=self.frame_cleanup,
            command=self.toggle_frame_cleanup
        )
        toggle_btn.pack(side="left")

        # Toggle log frame
        toggle_log_btn = ttk.Checkbutton(
            header_frame,
            text="Tampilkan Log",
            variable=self.show_log,
            command=self.toggle_log_frame
        )
        toggle_log_btn.pack(side="left", padx=(10, 0))  # beri jarak dari toggle advanced

        #Lampu Status
        self.status_runtime_var = tk.StringVar(value="idle")      # idle / busy
        self.status_result_var = tk.StringVar(value="none")       # none / success / error

        self.lamp_runtime = tk.Label(header_frame, width=2, height=1, bg="gray", relief="solid", bd=1)
        self.lamp_result = tk.Label(header_frame, width=2, height=1, bg="gray", relief="solid", bd=1)


        # Tombol Opsi (di kanan)
        settings_button = ttk.Button(
            header_frame,
            text="⚙️ Opsi",
            command=lambda: settingsPopup.open_settings_popup(self),
            style="Blue.TButton"
        )
        settings_button.pack(side="right")
        self.lamp_result.pack(side="right", padx=(0, 2))
        self.lamp_runtime.pack(side="right", padx=(0, 4))
        
        # CONTENT FRAMES
        self.content_frame = ttk.Frame(self.master)
        self.content_frame.pack(fill="both", expand=True)

        # === BASIC FRAMES ===
        # === BASIC FRAMES ===
        # === BASIC FRAMES ===
        self.input_frame = ttk.LabelFrame(self.master, text="Input", padding="6")
        self.input_frame.pack(in_=self.content_frame, padx=8, pady=(4, 2), fill="x")

        # Atur 4 kolom sama rata
        for col in range(4):
            self.input_frame.grid_columnconfigure(col, weight=1, uniform="input")
        for row in range(4):
            self.input_frame.grid_rowconfigure(row, weight=1, uniform="input")
        # baris 0
        # Username (label & entry)
        ttk.Label(self.input_frame, text="Username SSO:").grid(row=0, column=0, padx=3, pady=5, sticky="e")
        self.username_var = tk.StringVar()
        self.username_entry = ttk.Entry(self.input_frame, textvariable=self.username_var, style="Kipapp.TEntry")
        self.username_entry.grid(row=0, column=1, columnspan=2, padx=3, pady=5, sticky="ew")


        # baris 1
        # Password (label & entry)
        ttk.Label(self.input_frame, text="Password SSO:").grid(row=1, column=0, padx=3, pady=5, sticky="e")
        self.password_var = tk.StringVar()
        self.password_entry = ttk.Entry(self.input_frame, textvariable=self.password_var, show='*', style="Kipapp.TEntry")
        self.password_entry.grid(row=1, column=1, columnspan=2,  padx=3, pady=5, sticky="ew")

        # Mode Dropdown
        mode_dropdown = ttk.Combobox(
            self.input_frame,
            textvariable=self.import_mode,
            values=["Excel Lokal"
                    , "Excel BPS"
                    , "Gsheet"],
            state="readonly",
            style="KiPApp.TCombobox"
        )
        mode_dropdown.grid(row=3, column=0, padx=3, pady=5, sticky="ew")
        mode_dropdown.bind(
            "<<ComboboxSelected>>",
            lambda e: (self.update_import_ui(), config.set("import_mode", self.import_mode.get()))
        )

        # Bulan (label)
        ttk.Label(self.input_frame, text="Bulan:").grid(row=2, column=0, padx=3, pady=5, sticky="e")
        # Bulan (entry)
        self.inputMonth_var = tk.StringVar(value=bulan_otomatis)
        self.inputMonth_entry = ttk.Entry(self.input_frame, textvariable=self.inputMonth_var, style="Kipapp.TEntry")
        self.inputMonth_entry.grid(row=2, column=1, columnspan=2, padx=3, pady=5, sticky="ew")

        # baris 2
        # autofill
        btn_autofill = ttk.Button(self.input_frame, text="Autofill SSO", command=self.isi_credential_dev, style="Blue.TButton")
        btn_autofill.grid(row=0, column=3, rowspan=2, padx=3, pady=2, sticky="nsew")

        # baris 3
        # Entry path
        self.excel_file_path_var = tk.StringVar()
        self.excel_entry = ttk.Entry(self.input_frame, textvariable=self.excel_file_path_var, style="Kipapp.TEntry")
        self.excel_entry.grid(row=3, column=1, columnspan=2, padx=3, pady=5, sticky="ew")

        # Tombol browse/import
        self.btn_browse_excel_basic = ttk.Button(
            self.input_frame, text="Pilih File", command=self.select_excel_file, style="Green.TButton"
        )
        self.btn_browse_excel_basic.grid(row=3, column=3, padx=3, pady=5, sticky="ew")
        self.btn_view_table = ttk.Button(
            self.input_frame, text="Lihat Tabel", command=lambda: show_excel_as_table(self), style="Blue.TButton"
        )
        self.btn_view_table.grid(row=2, column=3, padx=3, pady=2, sticky="ew")

        ### === Frame Main === ###
        ### === Frame Main === ###
        ### === Frame Main === ###
        self.main_frame = ttk.LabelFrame(self.master, text="Main", padding="6")
        self.main_frame.pack(in_=self.content_frame, padx=8, pady=(2, 2), fill="x")

        # Konfigurasi grid untuk 3 kolom
        for col in range(3):
            self.main_frame.grid_columnconfigure(col, weight=1, uniform="main")

        # Baris 1
        self.btn_init_login = ttk.Button(
            self.main_frame, text="Inisialisasi", command=self.start_init_browser_thread, style="Green.TButton"
        )
        self.btn_init_login.grid(row=0, column=0, padx=3, pady=2, sticky="ew")

        self.btn_navigasi = ttk.Button(
            self.main_frame, text="Navigasi", command=self.start_navigasi_thread, style="Green.TButton"
        )
        self.btn_navigasi.grid(row=0, column=1, padx=3, pady=2, sticky="ew")

        self.btn_start_automation = ttk.Button(
            self.main_frame, text="Entri SKP", command=self.start_entri_thread, style="Green.TButton"
        )
        self.btn_start_automation.grid(row=0, column=2, padx=3, pady=2, sticky="ew")

        self.basic_frames = [
            self.input_frame,
            self.main_frame
        ]

        # ===== Frame Cleanup =====
        self.bawah_frame = ttk.LabelFrame(self.master, text="Cleanup", padding="6")
        # self.bawah_frame.pack(in_=self.content_frame, padx=8, pady=(2, 2), fill="x")

        for col in range(3):
            self.bawah_frame.grid_columnconfigure(col, weight=1, uniform="bawah")

        btn_stop_bottom = ttk.Button(
            self.bawah_frame, text="⛔ Stop Proses",
            command=self.stop_process, style="Red.TButton"
        )
        btn_stop_bottom.grid(row=0, column=0, padx=3, pady=2, sticky="ew")

        btn_delete_skp_bottom = ttk.Button(
            self.bawah_frame, text="Hapus SKP",
            style="Red.TButton",
            command=lambda: threading.Thread(target=app.hapus_baris_skp, daemon=True).start()
        )
        btn_delete_skp_bottom.grid(row=0, column=1, padx=3, pady=2, sticky="ew")

        btn_delete_rk_bottom = ttk.Button(
            self.bawah_frame, text="Hapus RK Kosong",
            style="Red.TButton",
            command=lambda: threading.Thread(target=app.delete_rk_kosong, daemon=True).start()
        )
        btn_delete_rk_bottom.grid(row=0, column=2, padx=3, pady=2, sticky="ew")
        self.advanced_frames = [
            self.input_frame,
            self.main_frame,
            self.bawah_frame
        ]


        ###FRAME DEVELOPER###
        ###FRAME DEVELOPER###
        ###FRAME DEVELOPER###
        # # Frame tambahan: Developer
        # developer_frame = ttk.LabelFrame(self.master, text="Developer", padding="6")
        # # developer_frame.pack(in_=self.content_frame, padx=10, pady=(5, 10), fill="x")
        # developer_frame.pack(in_=self.content_frame, padx=8, pady=(2, 2), fill="x")

        # # Konfigurasi grid untuk 3 kolom
        # for col in range(3):
        #     developer_frame.grid_columnconfigure(col, weight=1, uniform="dev")

        # # Satu baris 3 kolom
        # self.btn_close_browser = ttk.Button(
        #     developer_frame, text="Tutup Browser", command=self.close_browser, style="Red.TButton"
        # )
        # self.btn_close_browser.grid(row=0, column=0, padx=3, pady=2, sticky="ew")

        # # self.btn_close_app = ttk.Button(
        # #     developer_frame, text="Tutup Aplikasi", command=self.on_closing, style="Red.TButton"
        # # )
        # self.btn_close_app = ttk.Button(
        #     developer_frame, text="Tutup Aplikasi", command=self.import_gsheet, style="Red.TButton"
        # )
        # self.btn_close_app.grid(row=0, column=1, padx=3, pady=2, sticky="ew")

        # ttk.Button(
        #     developer_frame, text="Restart Aplikasi", command=self.restart_app, style="Yellow.TButton"
        # ).grid(row=0, column=2, padx=3, pady=2, sticky="ew")
        ###TAB DEVELOPER###
        ###TAB DEVELOPER###
        ###TAB DEVELOPER###
        
        self.log_frame = ttk.LabelFrame(self.master, text="Activity Log", padding="6")
        # log_frame.pack(padx=8, pady=(2, 2), fill="both", expand=True)
        self.log_frame.pack(padx=8, pady=2, fill="both")

        # Frame isi log
        log_inner = ttk.Frame(self.log_frame)
        log_inner.pack(fill="both")

        # self.log_text = tk.Text(log_inner, wrap="word", height=10, state=tk.DISABLED, bg="#f0f0f0")
        self.log_text = tk.Text(log_inner, wrap="word", height=10, state=tk.DISABLED, bg="white")
        self.log_text.pack(side="left", fill="both", expand=True)

        log_scrollbar = ttk.Scrollbar(log_inner, command=self.log_text.yview)
        log_scrollbar.pack(side="right", fill="y")
        self.log_text.config(yscrollcommand=log_scrollbar.set)

        self.footer_frame = tk.Frame(self.master, bg=self.master.cget("bg"))
        self.footer_frame.pack(pady=(2, 6))

        # # Label kiri: "© 2025 made with "
        # self.label_kiri = tk.Label(
        #     self.footer_frame,
        #     text="© 2025 made with ",
        #     font=("Arial", 9),
        #     foreground="gray",
        #     background=self.master.cget("bg")
        # )
        # self.label_kiri.pack(side="left")

        # Label © (klik untuk restart)
        self.label_copyright = tk.Label(
            self.footer_frame,
            text="©",
            font=("Arial", 9),
            foreground="gray",
            background=self.master.cget("bg"),
            cursor="hand2"
        )
        self.label_copyright.pack(side="left")
        self.label_copyright.bind("<Button-1>", lambda e: self.restart_app())

        # Label teks sisanya
        self.label_kiri = tk.Label(
            self.footer_frame,
            text=" 2025 made with ",
            font=("Arial", 9),
            foreground="gray",
            background=self.master.cget("bg")
        )
        self.label_kiri.pack(side="left")


        # Label love (❤), bisa diklik
        self.love = tk.Label(
            self.footer_frame,
            text="❤",
            font=("Arial", 9),
            foreground="gray",
            background=self.master.cget("bg"),
            cursor="hand2"
        )
        self.love.pack(side="left")
        self.love.bind("<Button-1>", lambda e: (
            theme.toggle_theme(self),
            theme.apply_dark(self) if self.dark_mode_enabled else theme.apply_light(self)
        ))

        # Label kanan: " Nama"
        self.label_kanan = tk.Label(
            self.footer_frame,
            text="Gilang Wahyu Prasetyo",
            font=("Arial", 9),
            foreground="gray",
            background=self.master.cget("bg")
        )
        self.label_kanan.pack(side="left")
        app.set_status_callback(lambda state, result: self.sync_lamp_status())
        self.sync_lamp_status()
        self.update_import_ui()

    def set_app_icon(self, icon_path="assets/favicon.ico"):
        try:
            icon_path = "assets/favicon.ico"
            img = Image.open(icon_path)
            self.app_icon = ImageTk.PhotoImage(img)
            self.master.iconphoto(True, self.app_icon)
        except FileNotFoundError:
            print(f"Error: File icon '{icon_path}' tidak ditemukan.")
        except Exception as e:
            print(f"Error saat mengatur icon aplikasi: {e}")

    def isi_credential_dev(self):
        success, username, password = app.load_credentials()
        if success:
            self.username_var.set(username)
            self.password_var.set(password)
            self.update_log_gui("Berhasil memuat credential.txt.")
        else:
            self.update_log_gui(
                "❌ Gagal membaca file credential.txt: "
                "file tidak ada atau isinya tidak sesuai.\n"
                "Aturan: buat credential.txt, "
                "baris pertama = username SSO anda, "
                "baris kedua = password."
            )

    def import_api_keys(self):
        success, api_key, api_secret, api_path = app.load_api_keys(full=True)
        if success:
            self.api_key_var.set(api_key)
            self.api_secret_var.set(api_secret)
            self.api_path_var.set(api_path)

            # ⬇⬇⬇ TAMBAHKAN INI ⬇⬇⬇
            app.USERNAME = api_key
            app.PASSWORD = api_secret
            app.ROOT_FOLDER = api_path
            # ⬆⬆⬆ TAMBAHKAN INI ⬆⬆⬆

            self.update_log_gui("✅ API key, secret, dan path Drive BPS berhasil dimuat dari api.txt.")
        else:
            self.update_log_gui(
                "❌ Gagal membaca file api.txt.\n"
                "Pastikan file tersedia dan memiliki minimal 3 baris: API Key, API Secret, dan path Drive BPS."
            )

    def update_lamps(self):
        runtime = self.status_runtime_var.get()
        result = self.status_result_var.get()

        if runtime == "busy":
            self.lamp_runtime.config(bg="yellow")
        else:
            self.lamp_runtime.config(bg="gray")

        if result == "success":
            self.lamp_result.config(bg="lime green")
        elif result == "error":
            self.lamp_result.config(bg="red")
        else:
            self.lamp_result.config(bg="gray")

    def stop_process(self):
        self.should_stop = True
        self.set_buttons_state(tk.NORMAL)
        self.update_log_gui("⛔ Proses dibatalkan oleh pengguna.")
        app.set_runtime_status("idle", "error")

    def sync_lamp_status(self):
        state, result = app.get_runtime_status()
        self.status_runtime_var.set(state)
        self.status_result_var.set(result)
        self.update_lamps()

        # Flag init
        if not hasattr(self, "_warned_type"):
            # None | "disconnected" | "closed"
            self._warned_type = None
        if not hasattr(self, "_pernah_ada_driver"):
            self._pernah_ada_driver = False

        # Deteksi driver aktif
        if app.get_driver() is not None:
            # Ada driver aktif → reset semua warning
            self._pernah_ada_driver = True
            self._warned_type = None
        else:
            # Tidak ada driver; hanya beri peringatan kalau:
            # - sebelumnya pernah ada driver (agar tidak warn saat awal-awal), dan
            # - tidak sedang busy (hindari tabrakan status), dan
            # - belum pernah warn dengan tipe ini (antispam)
            if self._pernah_ada_driver and state != "busy":
                kind = app.get_last_driver_error_type()  # "disconnected" | "closed" | None
                kind = kind or "closed"  # default jika None

                if self._warned_type != kind:
                    if kind == "disconnected":
                        self.update_log_gui("⚠️ Sesi Selenium terputus dari browser. Silakan re-inisialisasi koneksi.")
                    else:
                        self.update_log_gui("⚠️ Browser terdeteksi sudah tertutup. Silakan inisialisasi ulang.")
                    self._warned_type = kind
        self.master.after(200, self.sync_lamp_status)

    def update_log_gui(self, message):
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)
        self.master.update_idletasks()

    def set_buttons_state(self, state):
        # if state == tk.NORMAL:
        #     self.should_stop = False  # ⬅️ reset flag saat tombol-tombol diaktifkan lagi
        # self.btn_ubah_link.config(state=state)
        self.btn_init_login.config(state=state)
        self.btn_navigasi.config(state=state)
        self.btn_start_automation.config(state=state)
        # TAB DEVELOPER
        # self.btn_close_browser.config(state=state)
        # self.btn_close_app.config(state=state)
        # TAB DEVELOPER
        self.btn_view_table.config(state=state)

    def select_excel_file(self):
        app.get_runtime_status()
        file_path = filedialog.askopenfilename(
            title="Pilih File Excel SKP",
            filetypes=[("Excel files", "*.xlsx *.xls")]
        )
        if file_path:
            self.excel_file_path_var.set(file_path)
            self.update_log_gui(f"File Excel dipilih: {file_path}")

            success, headers, data = app.import_data(
                file_path,
                mode="Excel Lokal"
            )

            if success:
                self.cleaned_headers = list(headers)
                self.cleaned_data = [list(r) for r in data] 
                self.update_log_gui(f"✅ Import file lokal OK. \nHeaders: {headers}\nJumlah baris: {len(data)}")
                if not self.cleaned_data:
                    messagebox.showwarning("Data Kosong", "Import berhasil tetapi tidak ada baris data. Hanya ada header saja.")

            if headers:
                show_excel_as_table(self)
            else:
                return

    def start_init_browser_thread(self):
        if not self.username_var.get() or not self.password_var.get():
            messagebox.showwarning("Input Kurang", "Username dan Password SSO harus diisi.")
            return

        if app.get_driver():
            self.update_log_gui("⚠️ Ada browser yang masih terbuka. Tutup dulu kalau mau inisialisasi ulang.")
            return

        self.should_stop = False
        self.set_buttons_state(tk.DISABLED)
        print("🧵 Mulai thread inisialisasi")
        threading.Thread(target=self._run_init_browser, daemon=True).start()
        # print("🧵 Thread inisialisasi seharusnya sudah jalan")

    def _run_init_browser(self):
        if self.should_stop:
            return
        if app.init_browser_and_login(self.username_var.get(), self.password_var.get()):
            pass
            ##DEV##
            # self.master.after(100, lambda: messagebox.showinfo("Berhasil", "Login ke Kipapp berhasil!"))
            ##DEV##
        else:
            # popup gagal chrome
            # self.master.after(100, lambda: messagebox.showerror("Error", "Inisialisasi/Login Gagal. Cek log untuk detail."))
            pass
        self.master.after(100, lambda: self.set_buttons_state(tk.NORMAL))

    def toggle_frame_cleanup(self):
        if self.frame_cleanup.get():
            for frame in self.basic_frames:
                frame.pack_forget()
            for frame in self.advanced_frames:
                frame.pack(in_=self.content_frame, padx=8, pady=(4, 2), fill="x")
            # self.update_log_gui("Beralih ke advanced mode.")
            self.update_log_gui("Frame cleanup aktif.")
        else:
            for frame in self.advanced_frames:
                frame.pack_forget()
            for frame in self.basic_frames:
                frame.pack(in_=self.content_frame, padx=8, pady=(4, 2), fill="x")
            # self.update_log_gui("Beralih ke basic mode.")
            self.update_log_gui("Frame cleanup nonaktif.")
        self.update_import_ui()

    def toggle_log_frame(self):
        if self.show_log.get():
            self.log_frame.pack(before=self.footer_frame, padx=8, pady=(4, 6), fill="both", expand=True)
        else:
            self.log_frame.pack_forget()
        self.master.update_idletasks()
        self.master.geometry("")  # Reset ke auto-size

    def start_navigasi_thread(self):
        def run():
            try:
                input_month_name = self.inputMonth_var.get()
                if not app.navigasi(input_month_name):
                    self.master.after(100, lambda: messagebox.showerror("Error", "Navigasi gagal. Cek log untuk detail."))
            except Exception as e:
                app.update_log(f"EXCEPTION navigasi: {e}")
                self.master.after(100, lambda: messagebox.showerror("Error", f"Exception: {e}"))
            finally:
                self.master.after(100, lambda: self.set_buttons_state(tk.NORMAL))

        self.should_stop = False
        self.set_buttons_state(tk.DISABLED)
        threading.Thread(target=run, daemon=True).start()

    def start_entri_thread(self):
        self.should_stop = False
        self.set_buttons_state(tk.DISABLED)
        threading.Thread(target=self.run_entri_thread, daemon=True).start()

    def run_entri_thread(self):
        sukses = app.entri(
            self.inputMonth_var.get(),
            self.cleaned_data,
            should_stop_func=lambda: self.should_stop
        )

        if self.should_stop:
            self.master.after(100, lambda: messagebox.showwarning("Dihentikan", "⚠️ Proses entri dihentikan oleh pengguna."))
        elif sukses:
            self.master.after(100, lambda: messagebox.showinfo("Selesai", "✅ Semua data SKP berhasil diisi."))
            app.set_runtime_status("idle", "success")
        else:
            self.master.after(100, lambda: messagebox.showerror("Error", "❌ Gagal mengisi data SKP. Cek log untuk detail."))

        self.master.after(100, lambda: self.set_buttons_state(tk.NORMAL))
    
    def close_browser(self):
        app.close_browser()
        self.set_buttons_state(tk.NORMAL)

    def restart_app(self):
        app.restart_application(self.master)

    ## buat rename file ##
    ## buat rename file ##
    ## buat rename file ##
    def get_nama_file(self):
        if not getattr(self, "cleaned_data", None):
            self.update_log_gui("❌ Anda belum mengimpor data.")
            return

        folder = filedialog.askdirectory(title="Pilih Folder File Bukti Dukung")
        if not folder:
            return

        try:
            # Ambil hanya file biasa
            files = [f for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))]
            # files.sort(key=lambda f: os.path.getmtime(os.path.join(folder, f))) #sort by date
            files.sort(key=lambda f: f.lower()) #sort by name

            if len(files) != len(self.cleaned_data):
                self.update_log_gui("❌ Jumlah file tidak sama dengan jumlah baris data.")
                return

            # Pastikan semua baris punya kolom terakhir
            for row in self.cleaned_data:
                if len(row) < 5:
                    row.extend([""] * (5 - len(row)))

            # Ganti kolom terakhir cleaned_data dengan nama file
            for i, fname in enumerate(files):
                self.cleaned_data[i][4] = fname  # kolom ke-5 (indeks 4)

            # Refresh tampilan tabel
            if hasattr(self, "tree_ref"):
                td.update_treeview_data(
                    self.tree_ref, self,
                    {"checked": False},
                    lambda c: td.sort_by_column(self.tree_ref, c, {})
                )
            self.update_log_gui("📄 Nama file bukti dukung berhasil dimasukkan ke tabel.")

        except Exception as e:
            self.update_log_gui(f"❌ Gagal mengambil nama file: {e}")

    def select_rename_folder(self):
        if not getattr(self, "cleaned_data", None):
            self.update_log_gui("❌ Anda belum mengimpor data. Impor dulu.")
            return
        folder = filedialog.askdirectory(title="Pilih Folder untuk Rename File")
        if folder:
            self.rename_dir_var.set(folder)
            self.update_log_gui(f"📁 Folder dipilih: {folder}")

    def rename_file_in_folder(self):
        folder = self.rename_dir_var.get()
        if not os.path.isdir(folder):
            self.update_log_gui("❌ Path folder tidak valid.")
            return

        if not getattr(self, "cleaned_data", None):
            self.update_log_gui("❌ Anda belum mengimpor data. Impor dulu.")
            return
        self.renamed_filenames = []  # kosongkan dulu
        try:
            # Ambil hanya file biasa
            files = [f for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))]
            if not files:
                self.update_log_gui("❌ Folder kosong.")
                return

            # Pastikan pola nama awal 1,2,3,... (berbasis nama tanpa ekstensi)
            def stem_is_digit(f):
                return os.path.splitext(f)[0].isdigit()

            if not all(stem_is_digit(f) for f in files):
                self.update_log_gui("❌ Nama file awal harus bernomor 1,2,3,... sesuai urutan.")
                return

            # Urutkan berdasarkan angka pada nama file
            files.sort(key=lambda f: int(os.path.splitext(f)[0]))

            # Validasi jumlah
            if len(files) != len(self.cleaned_data):
                self.update_log_gui("❌ Jumlah file tidak sama dengan jumlah baris. Pastikan jumlahnya sama dulu sebelum me-_rename_.")
                return

            # Lakukan rename: file ke-i → "[kolom1] kolom3{ext}"
            # Asumsi cleaned_data adalah list of rows: [kol1, kol2, kol3, ...]
            renamed = 0
            for idx, filename in enumerate(files, start=1):
                row = self.cleaned_data[idx - 1]

                # pastikan kolom ke-5 tersedia
                if len(row) < 5:
                    row.extend([""] * (5 - len(row)))

                col1 = str(row[0]).strip() if len(row) > 0 and row[0] is not None else ""
                col3 = str(row[2]).strip() if len(row) > 2 and row[2] is not None else ""
                row[4] = f"[{col1}] {col3}"

                # Bentuk nama baru
                ext = os.path.splitext(filename)[1]
                # Sanitasi karakter terlarang di Windows
                safe = lambda s: "".join(c for c in s if c not in '<>:"/\\|?*').strip()
                new_name = f"[{safe(col1)}] {safe(col3)}{ext}"
                old_path = os.path.join(folder, filename)
                new_path = os.path.join(folder, new_name)

                # Jika target sudah ada, beri suffix numerik agar tidak bentrok
                if os.path.exists(new_path):
                    base, ext2 = os.path.splitext(new_name)
                    k = 1
                    while os.path.exists(os.path.join(folder, f"{base} ({k}){ext2}")):
                        k += 1
                    new_path = os.path.join(folder, f"{base} ({k}){ext2}")

                os.rename(old_path, new_path)
                renamed += 1
                self.renamed_filenames.append(os.path.basename(new_path))
                self.update_log_gui(f"✅ {filename} → {os.path.basename(new_path)}")

            self.update_log_gui(f"🎉 Selesai. {renamed} file berhasil di-rename.")

        except Exception as e:
            self.update_log_gui(f"❌ Gagal melakukan rename: {e}")

    def rename_file_in_table(self):
        if not getattr(self, "cleaned_data", None):
            self.update_log_gui("❌ Anda belum mengimpor data.")
            return

        # Pastikan setiap baris punya minimal 5 kolom
        for row in self.cleaned_data:
            if len(row) < 5:
                row.extend([""] * (5 - len(row)))

        # Kolom ke-5 = "[kolom_pertama] kolom_kedua"
        for row in self.cleaned_data:
            first = str(row[0]).strip() if row[0] is not None else ""
            second = str(row[2]).strip() if row[1] is not None else ""
            row[4] = f"[{first}] {second}"
        
        # update tampilan
        if hasattr(self, "tree_ref"):
                td.update_treeview_data(
                    self.tree_ref, self,
                    {"checked": False},
                    lambda c: td.sort_by_column(self.tree_ref, c, {})
                )
        # self.update_log_gui("🖊️ Nama file pada tabel berhasil diperbarui: "[kolom 1] + kolom 2".")
        self.update_log_gui('🖊️ Nama file pada tabel berhasil diperbarui menggunakan pola: "[kolom 1] kolom 2".')
    ## buat rename file ##
    ## buat rename file ##
    ## buat rename file ##

    def show_custom_nav_success_popup(self):
        popup = tk.Toplevel(self.master)
        popup.title("Navigasi Berhasil")
        popup.geometry("300x200")
        popup.transient(self.master)
        popup.grab_set()

        label = ttk.Label(popup, text="Navigasi ke halaman pelaksanaan SKP berhasil.", wraplength=280)
        label.pack(pady=15)

        btn_lanjutkan = ttk.Button(popup, text="Lanjutkan ke Entri", command=lambda: [popup.destroy(), self.start_entri_thread()])
        btn_lanjutkan.pack(pady=2, fill="x", padx=20)

        btn_ok = ttk.Button(popup, text="OK", command=popup.destroy)
        btn_ok.pack(pady=2, fill="x", padx=20)

        btn_tutup_browser = ttk.Button(popup, text="Tutup Browser", command=lambda: [popup.destroy(), self.close_browser()])
        btn_tutup_browser.pack(pady=2, fill="x", padx=20)

        popup.wait_window(popup)

    def import_gsheet(self):
        # ambil URL dari input field
        app.get_runtime_status()
        url = self.excel_file_path_var.get()

        # kalau masih mentahan, ubah ke format export xlsx
        if "docs.google.com/spreadsheets" in url and "/edit" in url:
            sheet_id = url.split("/d/")[1].split("/")[0]
            url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=xlsx"

        self.update_log_gui("Import dari Gsheets...")
        success, headers, data = app.import_data(
            url,
            mode="Gsheet"
        )
        if success:
            self.cleaned_headers = list(headers)
            self.cleaned_data = [list(r) for r in data] 
            # langsung tampilkan ke tabel
            self.update_log_gui(f"✅ Import Gsheet OK. Headers: {headers} | Baris: {len(data)}")
            if not self.cleaned_data:
                messagebox.showwarning("Data Kosong", "Import berhasil tetapi tidak ada baris data. Hanya ada header saja.")

        if headers:
                show_excel_as_table(self)
        else:
            return

    ### IMPORT DRIVEBPS ###
    def import_drive_bps(self):
        # ambil URL dari input field
        url = self.excel_file_path_var.get()

        self.update_log_gui("Import dari Excel BPS...")
        success, headers, data = app.import_data(
            url,
            mode="Excel BPS"
        )

        if success:
            self.cleaned_headers = list(headers)
            self.cleaned_data = [list(r) for r in data] 
            self.update_log_gui(f"✅ Import Drive BPS OK. Headers: {headers} | Baris: {len(data)}")
        
        if headers:
                show_excel_as_table(self)
        else:
            return

    def run_extract_links(self):
        app.set_runtime_status("busy", "none")
        self.should_stop = False  # reset manual (jaga-jaga kalau tombol belum aktif)
        self.set_buttons_state(tk.DISABLED)
        app.USERNAME = self.api_key_var.get()
        app.PASSWORD = self.api_secret_var.get()
        app.ROOT_FOLDER = self.api_path_var.get()
        try:
            if not self.cleaned_data:
                self.update_log_gui("❌ Data kosong, tidak ada link untuk diekstrak.")
                return

            diganti = 0
            for i, row in enumerate(self.cleaned_data, start=2):
                nama_file = str(row[-1]).strip() if row[-1] else ""
                if not nama_file:
                    self.update_log_gui(f"⚠️ Baris {i}: kolom terakhir kosong, dilewati.")
                    continue

                new_link = app.extract_link(nama_file)
                if self.should_stop:
                    return
                if new_link and new_link != nama_file:
                    row[-1] = new_link
                    diganti += 1
                    self.update_log_gui(f"🔗{i-1}. {nama_file} → {new_link}")
                else:
                    self.update_log_gui(f"❌ Gagal buat link ke-{i-1} untuk {nama_file}")
                if hasattr(self, "tree_ref"):
                    td.update_treeview_data(
                        self.tree_ref, self,
                        {"checked": False},
                        lambda c: td.sort_by_column(self.tree_ref, c, {})
                    )
            self.update_log_gui(f"✅ Konversi link selesai. {diganti} baris berhasil diganti.")
            app.set_runtime_status("idle", "success")

        except app.requests.exceptions.HTTPError as e:
            self.update_log_gui(f"❌ Gagal akses Drive BPS: {e}")
            app.set_runtime_status("idle", "error")
        except Exception as e:
            self.update_log_gui(f"❌ Error tak terduga saat konversi link: {e}")
        finally:
            self.set_buttons_state(tk.NORMAL)  # selalu aktifkan tombol kembali
    ### IMPORT DRIVEBPS ###

    def update_import_ui(self):
        mode = self.import_mode.get()

        for btn in [self.btn_browse_excel_basic]:
            if mode == "Excel Lokal":
                btn.config(
                    text="Pilih File",
                    command=self.select_excel_file
                )

            elif mode == "Gsheet":
                btn.config(
                    text="Import",
                    command=self.import_gsheet
                )

            elif mode == "Excel BPS":
                btn.config(
                    text="Import",
                    command=self.import_drive_bps
                )

    def on_closing(self):
        if app.get_driver():
            if messagebox.askokcancel("Tutup Aplikasi", "Apakah Anda yakin ingin menutup aplikasi? Browser yang aktif akan ditutup."):
                app.close_browser()
                self.master.destroy()
        else:
            self.master.destroy()

if __name__ == "__main__":
    print_logo_terminal(rel_path("../assets/favicon.ico"), width=50)
    root = tk.Tk()
    gui = KipappGUI(root)
    run_updatePopup(root)
    root.mainloop()