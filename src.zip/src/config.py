# config.py
import json, os

CONFIG_PATH = "config.json"
_config = None   # cache global
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def rel_path(relative):
    return os.path.join(os.path.dirname(__file__), relative)

def load():
    """Muat config ke cache kalau belum ada"""
    global _config
    if _config is None:
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    _config = json.load(f)
            except Exception:
                _config = {}
        else:
            _config = {}
    return _config

def save():
    """Simpan cache ke file"""
    global _config
    if _config is None:
        _config = {}
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(_config, f, indent=4)

def get(key):
    config = load()
    if key not in config:
        raise KeyError(f"'{key}' not found in config.json")
    return config[key]

def set(key, value, autosave=True):
    cfg = load()
    cfg[key] = value
    if autosave:
        save()
